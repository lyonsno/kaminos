# @kaminos/shader-herder

Run WebGPU shader tests from Node.js through Dawn, with WGSL compilation diagnostics, GPU numerical readback, validation error scopes and compute-loop instrumentation.

## Install

The package is currently distributed as a versioned npm archive. Install the archive supplied by the consuming repository:

```sh
npm install --save-dev ./artifacts/shader-herder/kaminos-shader-herder-0.1.1.tgz
```

The archive includes the runtime and this guide. It pins `webgpu` to version `0.6.2`; keep the consumer's lockfile committed. No neighboring source checkout is required. To build the same archive from source, run `npm ci` followed by `npm pack`.

## Evaluate shader math

```js
import { createGpuTestContext, evalWgslBatch } from '@kaminos/shader-herder';

const ctx = await createGpuTestContext(); // Requires an Apple hardware adapter.
try {
  const result = await evalWgslBatch(ctx, {
    argTypes: ['u32'],
    returnType: 'u32',
    body: 'return arg0 ^ 2u;',
    inputs: [[16777217]],
  });
  // result: [16777219], preserving integer precision above 2^24.
} finally {
  ctx.destroy();
}
```

`evalWgslBatch` accepts scalar `f32`, `u32` and `i32` arguments, plus scalar or `vec2`/`vec3`/`vec4` results. Pass actual production WGSL in `preamble`; `extractWgslFunction`, `extractWgslBlock` and `stripWgslBlock` help isolate it from larger sources. Extraction is targeted source scanning, not a complete WGSL parser.

## Validate and instrument production kernels

`ctx.compileShaderModule({ code, label })` throws `ShaderCompileError` with compiler diagnostics. `withGpuErrorScopes(device, label, fn)` reports validation and internal errors from pipeline creation, encoding and submission as `GpuValidationError`.

`runInstrumentedCompute(ctx, { code, entryPoint, workgroups, maxLoopIterations, maxThreadIterations, bindings, outputBuffer, outputBufferSize, constants })` instruments compute loops, dispatches them and reads their output. A trip throws `ShaderLoopTripwireError`, including the offending loop, invocation and iteration telemetry. Limits are explicit test expectations; exceeding them fails the test rather than accepting truncated output. The runner currently binds group 0 and reserves binding 63 by default; select `tripwireBinding` if that slot is occupied.

Loop instrumentation adds atomic operations and changes the shader. Use it for numerical regression and excessive-iteration checks, and use uninstrumented kernels for timing. The scanner's tested loop forms do not establish support for every WGSL construct or universal protection from GPU hangs.

## Evidence routes

The default device route requires Apple hardware and rejects fallback adapters. `AdapterIdentityError` reports missing or mismatched hardware. A macOS sandbox may reject Metal shared-event creation with `ERR_METAL_SANDBOX_SHARED_EVENT`.

For compiler and pipeline validation without hardware execution, explicitly select:

```js
const ctx = await createGpuTestContext({
  dawnFlags: ['backend=null'],
  requiredVendor: null,
  allowFallbackAdapter: true,
});
```

A null-backend result establishes compilation and validation only. It does not establish numerical output, loop execution or timing. The core package does not silently select it when hardware fails.

`ctx.profileCommandSubmission(recordFn, { watchdogCliffMs, scaleMultiplier, maxPasses })` collects hardware timestamps for compute/render passes and checks individual and summed pass durations. The check runs after GPU execution; it cannot prevent the first watchdog reset. `scaleMultiplier` is a caller-supplied projection, not a measured larger run.

## Develop and test

```sh
npm ci
npm test                 # Standalone compiler/routing checks plus Apple hardware numerics.
npm run test:compile     # Explicit Dawn backend=null; no GPU numerical claim.
npm run test:native      # Apple hardware numerics, validation and loop telemetry.
```

Native hardware checks fail when the required adapter is unavailable. They do not convert a hardware failure into a compiler-only pass. Profiling has a separate `npm run test:profile` command; run it in the environment used for performance work.

Production Kaminos fixtures are retained as an explicit integration suite:

```sh
KAMINOS_ROOT=/absolute/path/to/kaminos npm run test:integration
```

The suite reports the selected root and rejects missing or invalid roots. Its joined-optical and World/Fine fixtures depend on the shader layout exercised by the original integration. Run it against that compatible revision; current-main consumer tests belong with Kaminos and follow its evolving production kernels.
