import { create as createDawnGpu, globals as dawnGlobals } from 'webgpu';

export class AdapterIdentityError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'AdapterIdentityError';
    this.details = details;
    if (details.code) this.code = details.code;
  }
}

export class GpuValidationError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'GpuValidationError';
    this.details = details;
  }
}

export class ShaderCompileError extends Error {
  constructor(message, messages = [], code = '') {
    super(message);
    this.name = 'ShaderCompileError';
    this.messages = messages;
    this.code = code;
  }
}

export class ShaderLoopTripwireError extends Error {
  constructor(message, telemetry) {
    super(message);
    this.name = 'ShaderLoopTripwireError';
    this.telemetry = telemetry;
  }
}

export class WatchdogCliffError extends Error {
  constructor(message, profile) {
    super(message);
    this.name = 'WatchdogCliffError';
    this.profile = profile;
  }
}

function coercePipelineStageConstants(stage) {
  if (!stage || !stage.constants) return stage;
  const coerced = {};
  for (const [k, v] of Object.entries(stage.constants)) {
    coerced[k] = typeof v === 'boolean' ? (v ? 1 : 0) : v;
  }
  return { ...stage, constants: coerced };
}

function coerceComputePipelineDesc(desc) {
  if (!desc || !desc.compute?.constants) return desc;
  return {
    ...desc,
    compute: coercePipelineStageConstants(desc.compute),
  };
}

function coerceRenderPipelineDesc(desc) {
  if (!desc || (!desc.vertex?.constants && !desc.fragment?.constants)) return desc;
  return {
    ...desc,
    ...(desc.vertex ? { vertex: coercePipelineStageConstants(desc.vertex) } : {}),
    ...(desc.fragment ? { fragment: coercePipelineStageConstants(desc.fragment) } : {}),
  };
}

function wrapNativeDevice(device) {
  return new Proxy(device, {
    get(target, prop) {
      if (prop === 'addEventListener') {
        if (typeof target.addEventListener === 'function') {
          return target.addEventListener.bind(target);
        }
        return (type, fn) => {
          if (type === 'uncapturederror' && 'onuncapturederror' in target) {
            target.onuncapturederror = fn;
          }
        };
      }
      if (prop === 'removeEventListener') {
        if (typeof target.removeEventListener === 'function') {
          return target.removeEventListener.bind(target);
        }
        return (type) => {
          if (type === 'uncapturederror' && 'onuncapturederror' in target) {
            target.onuncapturederror = null;
          }
        };
      }
      if (prop === 'createComputePipeline') {
        return (desc) => target.createComputePipeline(coerceComputePipelineDesc(desc));
      }
      if (prop === 'createComputePipelineAsync') {
        return (desc) => target.createComputePipelineAsync(coerceComputePipelineDesc(desc));
      }
      if (prop === 'createRenderPipeline') {
        return (desc) => target.createRenderPipeline(coerceRenderPipelineDesc(desc));
      }
      if (prop === 'createRenderPipelineAsync') {
        return (desc) => target.createRenderPipelineAsync(coerceRenderPipelineDesc(desc));
      }
      const val = Reflect.get(target, prop, target);
      return typeof val === 'function' ? val.bind(target) : val;
    },
  });
}

const _dawnGpuCache = new Map();
const _retainedDawnHandles = [];
let _cachedMetalSandboxError = null;

function normalizeAdapterInfo(info = {}) {
  return {
    vendor: info.vendor ?? '',
    architecture: info.architecture ?? '',
    device: info.device ?? '',
    description: info.description ?? '',
    isFallbackAdapter: Boolean(info.isFallbackAdapter),
  };
}

function wrapNativeAdapter(adapter) {
  _retainedDawnHandles.push(adapter);
  return new Proxy(adapter, {
    get(target, prop) {
      if (prop === 'requestDevice') {
        return async (desc) => {
          if (
            (process.env.SHADER_HERDER_FORCE_SEATBELT_FALLBACK === '1' ||
              _cachedMetalSandboxError !== null) &&
            target.info?.vendor === 'apple'
          ) {
            throw new AdapterIdentityError(
              _cachedMetalSandboxError?.message ??
                'Simulated Seatbelt MTLSharedEvent restriction after adapter validation',
              {
                code: 'ERR_METAL_SANDBOX_SHARED_EVENT',
                adapterInfo: normalizeAdapterInfo(target.info),
                cause: _cachedMetalSandboxError?.cause,
              }
            );
          }
          try {
            const dev = await target.requestDevice(desc);
            _retainedDawnHandles.push(dev);
            return wrapNativeDevice(dev);
          } catch (err) {
            if (String(err?.message || err).includes('MTLSharedEvent')) {
              const message =
                `Metal shared event creation failed inside Seatbelt sandbox (${err.message}). ` +
                `Run outside sandbox for hardware Metal execution or pass dawnFlags: ['backend=null'] with allowFallbackAdapter: true for in-sandbox compiler/validation tests.`;
              _cachedMetalSandboxError = { message, cause: err };
              throw new AdapterIdentityError(message, {
                code: 'ERR_METAL_SANDBOX_SHARED_EVENT',
                adapterInfo: normalizeAdapterInfo(target.info),
                cause: err,
              });
            }
            throw err;
          }
        };
      }
      const val = Reflect.get(target, prop, target);
      return typeof val === 'function' ? val.bind(target) : val;
    },
  });
}

export async function withGpuErrorScopes(device, label, fn) {
  device.pushErrorScope('validation');
  device.pushErrorScope('internal');
  let fnErr = null;
  let result;
  try {
    result = await fn();
  } catch (err) {
    fnErr = err;
  }
  const internalErr = await device.popErrorScope();
  const validationErr = await device.popErrorScope();
  if (fnErr) {
    throw fnErr;
  }
  const gpuErr = internalErr || validationErr;
  if (gpuErr) {
    throw new GpuValidationError(
      `WebGPU validation/internal error in "${label}": ${gpuErr.message}`,
      { label, gpuError: gpuErr }
    );
  }
  return result;
}

export function installNativeWebGPU(options = {}) {
  const { dawnFlags = [] } = options;
  Object.assign(globalThis, dawnGlobals);
  const cacheKey = dawnFlags.join('\0');
  let rawGpu = _dawnGpuCache.get(cacheKey);
  if (!rawGpu) {
    rawGpu = createDawnGpu(dawnFlags);
    _dawnGpuCache.set(cacheKey, rawGpu);
    _retainedDawnHandles.push(rawGpu);
  }
  const gpu = new Proxy(rawGpu, {
    get(target, prop) {
      if (prop === 'requestAdapter') {
        return async (opts) => {
          const adapter = await target.requestAdapter(opts);
          return adapter ? wrapNativeAdapter(adapter) : null;
        };
      }
      const val = Reflect.get(target, prop, target);
      return typeof val === 'function' ? val.bind(target) : val;
    },
  });
  if (!globalThis.navigator) {
    Object.defineProperty(globalThis, 'navigator', {
      value: { gpu },
      configurable: true,
      writable: true,
    });
  } else {
    Object.defineProperty(globalThis.navigator, 'gpu', {
      value: gpu,
      configurable: true,
      writable: true,
    });
  }
  return gpu;
}

export async function createGpuTestContext(options = {}) {
  const {
    dawnFlags = [],
    requiredFeatures = ['timestamp-query'],
    requiredLimits = {},
    requiredVendor = 'apple',
    allowFallbackAdapter = false,
  } = options;
  const gpu = installNativeWebGPU({ dawnFlags });
  const adapter = await gpu.requestAdapter();
  if (!adapter) {
    throw new AdapterIdentityError('Native WebGPU adapter unavailable (dawn-node returned null)');
  }
  const info = adapter.info ?? {};
  const isNullOrFallback =
    Boolean(info.isFallbackAdapter) ||
    !info.vendor ||
    info.vendor === 'none' ||
    String(info.architecture || '').includes('null') ||
    dawnFlags.some((f) => String(f).includes('backend=null'));

  if (!allowFallbackAdapter && isNullOrFallback) {
    throw new AdapterIdentityError(
      `Refusing software/null/fallback WebGPU adapter: vendor="${info.vendor}", architecture="${info.architecture}"`,
      { adapterInfo: info }
    );
  }
  if (requiredVendor && info.vendor !== requiredVendor) {
    throw new AdapterIdentityError(
      `WebGPU adapter vendor mismatch: required "${requiredVendor}", got "${info.vendor}" (architecture="${info.architecture}")`,
      { requiredVendor, adapterInfo: info }
    );
  }

  const features = [];
  for (const feat of requiredFeatures) {
    if (adapter.features.has(feat)) {
      features.push(feat);
    }
  }
  const hasTimestampQuery = features.includes('timestamp-query');
  const device = await adapter.requestDevice({
    requiredFeatures: features,
    requiredLimits,
  });

  const adapterInfo = {
    vendor: info.vendor ?? '',
    architecture: info.architecture ?? '',
    device: info.device ?? '',
    description: info.description ?? '',
    isFallbackAdapter: Boolean(info.isFallbackAdapter),
  };

  async function compileShaderModule({ code, label = 'shader-module' }) {
    device.pushErrorScope('validation');
    device.pushErrorScope('internal');
    const module = device.createShaderModule({ label, code });
    const compilationInfo = await module.getCompilationInfo();
    const internalErr = await device.popErrorScope();
    const validationErr = await device.popErrorScope();

    const errors = (compilationInfo?.messages ?? []).filter((m) => m.type === 'error');
    if (errors.length > 0 || validationErr || internalErr) {
      const formatted = errors
        .map((m) => `line ${m.lineNum}:${m.linePos} - ${m.message}`)
        .join('\n');
      const scopeMsg = validationErr?.message || internalErr?.message || '';
      throw new ShaderCompileError(
        `WGSL compilation failed for "${label}":\n${formatted || scopeMsg}`,
        compilationInfo?.messages ?? [],
        code
      );
    }
    return module;
  }

  async function profileCommandSubmission(
    recordFn,
    { watchdogCliffMs = 2000, scaleMultiplier = 1, maxPasses = 32 } = {}
  ) {
    if (!hasTimestampQuery) {
      throw new Error('Hardware timestamp-query is not enabled on this WebGPU device');
    }
    const queryCapacity = maxPasses * 2;
    const querySet = device.createQuerySet({
      type: 'timestamp',
      count: queryCapacity,
    });
    const resolveBuffer = device.createBuffer({
      size: queryCapacity * 8,
      usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC,
    });
    const readbackBuffer = device.createBuffer({
      size: queryCapacity * 8,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    });

    const rawEncoder = device.createCommandEncoder({ label: 'profiled-command-encoder' });
    const passRecords = [];

    const attachTimestamps = (desc, defaultLabel) => {
      const normalized = desc ?? {};
      const passIndex = passRecords.length;
      if (passIndex >= maxPasses) {
        throw new Error(`Exceeded maxPasses (${maxPasses}) in profileCommandSubmission`);
      }
      const beginIdx = passIndex * 2;
      const endIdx = passIndex * 2 + 1;
      const label = normalized.label ?? `${defaultLabel}-${passIndex}`;
      passRecords.push({ index: passIndex, label, beginIdx, endIdx });
      return {
        ...normalized,
        label,
        timestampWrites: {
          querySet,
          beginningOfPassWriteIndex: beginIdx,
          endOfPassWriteIndex: endIdx,
        },
      };
    };

    const wrappedEncoder = new Proxy(rawEncoder, {
      get(target, prop) {
        if (prop === 'beginComputePass') {
          return (desc) => target.beginComputePass(attachTimestamps(desc, 'compute-pass'));
        }
        if (prop === 'beginRenderPass') {
          return (desc) => target.beginRenderPass(attachTimestamps(desc, 'render-pass'));
        }
        const val = Reflect.get(target, prop, target);
        return typeof val === 'function' ? val.bind(target) : val;
      },
    });

    try {
      const usedQueries = await withGpuErrorScopes(device, 'profileCommandSubmission', async () => {
        await recordFn(wrappedEncoder);
        const count = passRecords.length * 2;
        if (count > 0) {
          rawEncoder.resolveQuerySet(querySet, 0, count, resolveBuffer, 0);
          rawEncoder.copyBufferToBuffer(resolveBuffer, 0, readbackBuffer, 0, count * 8);
        }
        device.queue.submit([rawEncoder.finish()]);
        return count;
      });

      if (usedQueries === 0) {
        await device.queue.onSubmittedWorkDone();
        return { passes: [], totalDurationNs: 0n, totalDurationMs: 0, projectedTotalMs: 0 };
      }

      await readbackBuffer.mapAsync(GPUMapMode.READ);
      const timestamps = new BigUint64Array(readbackBuffer.getMappedRange().slice(0, usedQueries * 8));
      readbackBuffer.unmap();

      let totalDurationNs = 0n;
      const passes = passRecords.map((rec) => {
        const startNs = timestamps[rec.beginIdx];
        const endNs = timestamps[rec.endIdx];
        const durationNs = endNs >= startNs ? endNs - startNs : 0n;
        totalDurationNs += durationNs;
        const durationMs = Number(durationNs) / 1e6;
        const projectedMs = durationMs * scaleMultiplier;
        return {
          label: rec.label,
          durationNs,
          durationMs,
          projectedMs,
        };
      });

      const totalDurationMs = Number(totalDurationNs) / 1e6;
      const projectedTotalMs = totalDurationMs * scaleMultiplier;

      for (const pass of passes) {
        if (pass.projectedMs >= watchdogCliffMs) {
          throw new WatchdogCliffError(
            `GPU pass "${pass.label}" measured ${pass.durationMs.toFixed(3)} ms ` +
              `(projected ${pass.projectedMs.toFixed(3)} ms at ${scaleMultiplier}x scale), ` +
              `exceeding watchdog cliff budget ${watchdogCliffMs} ms`,
            { pass, watchdogCliffMs, scaleMultiplier, allPasses: passes, totalDurationMs, projectedTotalMs }
          );
        }
      }

      if (projectedTotalMs >= watchdogCliffMs) {
        throw new WatchdogCliffError(
          `Cumulative GPU command submission across ${passes.length} passes measured ${totalDurationMs.toFixed(3)} ms ` +
            `(projected ${projectedTotalMs.toFixed(3)} ms at ${scaleMultiplier}x scale), ` +
            `exceeding watchdog cliff budget ${watchdogCliffMs} ms (${passes.map((p) => p.label).join(', ')})`,
          { pass: null, watchdogCliffMs, scaleMultiplier, allPasses: passes, totalDurationMs, projectedTotalMs }
        );
      }

      return { passes, totalDurationNs, totalDurationMs, projectedTotalMs };
    } finally {
      querySet.destroy();
      resolveBuffer.destroy();
      readbackBuffer.destroy();
    }
  }

  return {
    gpu,
    adapter,
    adapterInfo,
    features,
    hasTimestampQuery,
    device,
    compileShaderModule,
    profileCommandSubmission,
    destroy() {
      device.destroy();
    },
  };
}

function skipWsAndComments(code, idx) {
  let i = idx;
  const n = code.length;
  while (i < n) {
    const ch = code[i];
    if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') {
      i++;
      continue;
    }
    if (ch === '/' && code[i + 1] === '/') {
      i += 2;
      while (i < n && code[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && code[i + 1] === '*') {
      i += 2;
      while (i < n && !(code[i] === '*' && code[i + 1] === '/')) i++;
      if (i < n) i += 2;
      continue;
    }
    break;
  }
  return i;
}

function findMatchingDelimiter(code, openIdx, openChar, closeChar) {
  let depth = 0;
  let i = openIdx;
  const n = code.length;
  while (i < n) {
    if (code[i] === '/' && code[i + 1] === '/') {
      i += 2;
      while (i < n && code[i] !== '\n') i++;
      continue;
    }
    if (code[i] === '/' && code[i + 1] === '*') {
      i += 2;
      while (i < n && !(code[i] === '*' && code[i + 1] === '/')) i++;
      if (i < n) i += 2;
      continue;
    }
    if (code[i] === openChar) {
      depth++;
    } else if (code[i] === closeChar) {
      depth--;
      if (depth === 0) return i;
    }
    i++;
  }
  return -1;
}

export function extractWgslFunction(sourceText, fnName) {
  const escaped = fnName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`\\bfn\\s+${escaped}\\s*\\(`, 'g');
  const match = re.exec(sourceText);
  if (!match) {
    throw new Error(`Could not find WGSL function "${fnName}"`);
  }
  const startIdx = match.index;
  const openParenIdx = startIdx + match[0].length - 1;
  const closeParenIdx = findMatchingDelimiter(sourceText, openParenIdx, '(', ')');
  if (closeParenIdx < 0) {
    throw new Error(`Unbalanced parentheses in WGSL function "${fnName}"`);
  }
  const openBraceIdx = sourceText.indexOf('{', closeParenIdx + 1);
  if (openBraceIdx < 0) {
    throw new Error(`Could not find opening brace for WGSL function "${fnName}"`);
  }
  const closeBraceIdx = findMatchingDelimiter(sourceText, openBraceIdx, '{', '}');
  if (closeBraceIdx < 0) {
    throw new Error(`Unbalanced braces in WGSL function "${fnName}"`);
  }
  return sourceText.slice(startIdx, closeBraceIdx + 1);
}

export function extractWgslBlock(sourceText, headerMarker) {
  const startIdx = sourceText.indexOf(headerMarker);
  if (startIdx < 0) {
    throw new Error(`Could not find WGSL block marker: ${headerMarker}`);
  }
  const openBraceIdx = sourceText.indexOf('{', startIdx);
  if (openBraceIdx < 0) {
    throw new Error(`Could not find opening brace after marker: ${headerMarker}`);
  }
  const closeBraceIdx = findMatchingDelimiter(sourceText, openBraceIdx, '{', '}');
  if (closeBraceIdx < 0) {
    throw new Error(`Unbalanced braces for WGSL block marker: ${headerMarker}`);
  }
  return sourceText.slice(startIdx, closeBraceIdx + 1);
}

export function stripWgslBlock(sourceText, headerMarker) {
  const block = extractWgslBlock(sourceText, headerMarker);
  return sourceText.replace(block, '');
}

function isIdentChar(ch) {
  if (!ch) return false;
  const c = ch.charCodeAt(0);
  return (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 95;
}

function findLeadingDirectiveEnd(code) {
  let i = 0;
  const n = code.length;
  while (i < n) {
    const next = skipWsAndComments(code, i);
    if (next >= n) break;
    const sub = code.slice(next);
    const m = sub.match(/^(?:enable|requires|diagnostic)\b[^;]*;/);
    if (m) {
      i = next + m[0].length;
    } else {
      break;
    }
  }
  return i;
}

/**
 * Instruments WGSL `while (...) {`, `for (...) {`, and `loop {` constructs with
 * a comment-aware balanced-parenthesis scanner and an atomic iteration counter +
 * per-thread tripwire ceiling so runaway loops and nested-loop blowups abort in
 * milliseconds and report the exact offending invocation ID.
 */
export function instrumentWgslLoops(
  code,
  {
    maxIterations = 1024,
    maxThreadIterations = maxIterations * 16,
    group = 0,
    binding = 63,
  } = {}
) {
  let loopCount = 0;
  const edits = []; // { start, end, replacement }

  const n = code.length;
  let i = 0;
  while (i < n) {
    // Skip comments
    if (code[i] === '/' && code[i + 1] === '/') {
      i += 2;
      while (i < n && code[i] !== '\n') i++;
      continue;
    }
    if (code[i] === '/' && code[i + 1] === '*') {
      i += 2;
      while (i < n && !(code[i] === '*' && code[i + 1] === '/')) i++;
      if (i < n) i += 2;
      continue;
    }

    // Check for `@compute` entry points to inject `_sh_current_gid` and heartbeat `atomicAdd(&_sh_tripwire[8], 1u)`
    if (code[i] === '@' && code.slice(i, i + 8) === '@compute' && !isIdentChar(code[i + 8])) {
      let fnSearch = i + 8;
      while (fnSearch < n) {
        fnSearch = skipWsAndComments(code, fnSearch);
        if (code.slice(fnSearch, fnSearch + 2) === 'fn' && !isIdentChar(code[fnSearch + 2])) {
          break;
        }
        // Skip attributes like @workgroup_size(...)
        if (code[fnSearch] === '@') {
          fnSearch++;
          while (fnSearch < n && isIdentChar(code[fnSearch])) fnSearch++;
          fnSearch = skipWsAndComments(code, fnSearch);
          if (code[fnSearch] === '(') {
            const closeAttr = findMatchingDelimiter(code, fnSearch, '(', ')');
            if (closeAttr > 0) fnSearch = closeAttr + 1;
          }
          continue;
        }
        break;
      }
      if (code.slice(fnSearch, fnSearch + 2) === 'fn' && !isIdentChar(code[fnSearch + 2])) {
        const openParen = code.indexOf('(', fnSearch + 2);
        const closeParen = openParen >= 0 ? findMatchingDelimiter(code, openParen, '(', ')') : -1;
        const openBrace = closeParen >= 0 ? skipWsAndComments(code, closeParen + 1) : -1;
        if (openParen >= 0 && closeParen >= 0 && openBrace >= 0 && code[openBrace] === '{') {
          const paramsText = code.slice(openParen + 1, closeParen);
          const gidMatch = paramsText.match(
            /@builtin\(\s*global_invocation_id\s*\)\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(?:vec3<\s*u32\s*>|vec3u\b)/
          );
          if (gidMatch) {
            const gidIdent = gidMatch[1];
            edits.push({
              start: openBrace,
              end: openBrace + 1,
              replacement: `{\n  _sh_current_gid = ${gidIdent};\n  atomicAdd(&_sh_tripwire[8], 1u);`,
            });
          } else {
            const trimmedParams = paramsText.trim();
            const comma = trimmedParams.length > 0 && !trimmedParams.endsWith(',') ? ', ' : '';
            edits.push({
              start: closeParen,
              end: closeParen + 1,
              replacement: `${comma}@builtin(global_invocation_id) _sh_auto_gid: vec3<u32>)`,
            });
            edits.push({
              start: openBrace,
              end: openBrace + 1,
              replacement: `{\n  _sh_current_gid = _sh_auto_gid;\n  atomicAdd(&_sh_tripwire[8], 1u);`,
            });
          }
          i = openBrace + 1;
          continue;
        }
      }
    }

    // Check for `while`, `for`, `loop` keywords at identifier boundaries
    if (!isIdentChar(code[i - 1])) {
      if (
        (code.slice(i, i + 5) === 'while' && !isIdentChar(code[i + 5])) ||
        (code.slice(i, i + 3) === 'for' && !isIdentChar(code[i + 3]))
      ) {
        const kwLen = code[i] === 'w' ? 5 : 3;
        const afterKw = skipWsAndComments(code, i + kwLen);
        if (code[afterKw] === '(') {
          const closeParen = findMatchingDelimiter(code, afterKw, '(', ')');
          if (closeParen > 0) {
            const openBrace = skipWsAndComments(code, closeParen + 1);
            if (code[openBrace] === '{') {
              const id = loopCount++;
              const originalHeader = code.slice(i, openBrace + 1);
              edits.push({
                start: i,
                end: openBrace + 1,
                replacement: `_sh_thread_iters[${id}u] = 0u; ${originalHeader}\n      if (_sh_check_tripwire(${id}u)) { break; }`,
              });
              i = openBrace + 1;
              continue;
            }
          }
        }
      } else if (code.slice(i, i + 4) === 'loop' && !isIdentChar(code[i + 4])) {
        const openBrace = skipWsAndComments(code, i + 4);
        if (code[openBrace] === '{') {
          const id = loopCount++;
          const originalHeader = code.slice(i, openBrace + 1);
          edits.push({
            start: i,
            end: openBrace + 1,
            replacement: `_sh_thread_iters[${id}u] = 0u; ${originalHeader}\n      if (_sh_check_tripwire(${id}u)) { break; }`,
          });
          i = openBrace + 1;
          continue;
        }
      }
    }

    i++;
  }

  // Apply edits in reverse order so indices stay valid
  edits.sort((a, b) => b.start - a.start);
  let transformed = code;
  for (const edit of edits) {
    transformed = transformed.slice(0, edit.start) + edit.replacement + transformed.slice(edit.end);
  }

  const header = `
@group(${group}) @binding(${binding}) var<storage, read_write> _sh_tripwire: array<atomic<u32>, 9>;
var<private> _sh_current_gid: vec3<u32> = vec3<u32>(0u, 0u, 0u);
var<private> _sh_thread_tripped: bool = false;
var<private> _sh_thread_total_iters: u32 = 0u;
var<private> _sh_thread_iters: array<u32, ${Math.max(1, loopCount)}> = array<u32, ${Math.max(1, loopCount)}>();

fn _sh_check_tripwire(loopId: u32) -> bool {
  if (_sh_thread_tripped) {
    return true;
  }
  let nextIter = _sh_thread_iters[loopId] + 1u;
  let nextTotal = _sh_thread_total_iters + 1u;
  _sh_thread_iters[loopId] = nextIter;
  _sh_thread_total_iters = nextTotal;
  let peakIter = max(nextIter, nextTotal);
  atomicAdd(&_sh_tripwire[1], 1u);
  atomicMax(&_sh_tripwire[2], peakIter);
  if (nextIter > ${maxIterations}u || nextTotal > ${maxThreadIterations}u) {
    _sh_thread_tripped = true;
    if (atomicExchange(&_sh_tripwire[0], 1u) == 0u) {
      atomicStore(&_sh_tripwire[3], loopId);
      atomicStore(&_sh_tripwire[4], _sh_current_gid.x);
      atomicStore(&_sh_tripwire[5], _sh_current_gid.y);
      atomicStore(&_sh_tripwire[6], _sh_current_gid.z);
      atomicStore(&_sh_tripwire[7], select(${maxIterations}u, ${maxThreadIterations}u, nextTotal > ${maxThreadIterations}u));
    }
    return true;
  }
  return false;
}
`;

  const directiveEnd = findLeadingDirectiveEnd(transformed);
  const finalCode =
    directiveEnd > 0
      ? `${transformed.slice(0, directiveEnd)}\n${header}\n${transformed.slice(directiveEnd)}`
      : `${header}\n${transformed}`;

  return {
    code: finalCode,
    loopCount,
    group,
    binding,
    maxIterations,
    maxThreadIterations,
  };
}

export async function runInstrumentedCompute(
  ctx,
  {
    label = 'instrumented-compute',
    code,
    entryPoint = 'main',
    constants = undefined,
    workgroups = [1, 1, 1],
    maxLoopIterations = 1024,
    maxThreadIterations = maxLoopIterations * 16,
    outputBuffer = null,
    outputBufferSize = 64,
    bindings = [],
    tripwireBinding = 63,
  }
) {
  const instrumented = instrumentWgslLoops(code, {
    maxIterations: maxLoopIterations,
    maxThreadIterations,
    group: 0,
    binding: tripwireBinding,
  });

  const module = await ctx.compileShaderModule({ label, code: instrumented.code });

  const ownsOutBuf = !outputBuffer;
  const outBuf =
    outputBuffer ??
    ctx.device.createBuffer({
      label: `${label}-out`,
      size: outputBufferSize,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
    });
  const outRead = ctx.device.createBuffer({
    label: `${label}-out-read`,
    size: outputBufferSize,
    usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
  });

  const tripwireBytes = 9 * 4;
  const tripwireBuf = ctx.device.createBuffer({
    label: `${label}-tripwire`,
    size: tripwireBytes,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
  });
  const tripwireRead = ctx.device.createBuffer({
    label: `${label}-tripwire-read`,
    size: tripwireBytes,
    usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
  });

  try {
    await withGpuErrorScopes(ctx.device, label, async () => {
      const pipeline = ctx.device.createComputePipeline({
        label: `${label}-pipeline`,
        layout: 'auto',
        compute: {
          module,
          entryPoint,
          ...(constants ? { constants } : {}),
        },
      });

      const userEntries =
        bindings.length > 0 ? bindings : [{ binding: 0, resource: { buffer: outBuf } }];
      const bindGroup = ctx.device.createBindGroup({
        layout: pipeline.getBindGroupLayout(0),
        entries: [
          ...userEntries,
          { binding: tripwireBinding, resource: { buffer: tripwireBuf } },
        ],
      });

      const encoder = ctx.device.createCommandEncoder({ label: `${label}-encoder` });
      const pass = encoder.beginComputePass({ label });
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bindGroup);
      pass.dispatchWorkgroups(workgroups[0] ?? 1, workgroups[1] ?? 1, workgroups[2] ?? 1);
      pass.end();

      encoder.copyBufferToBuffer(outBuf, 0, outRead, 0, outputBufferSize);
      encoder.copyBufferToBuffer(tripwireBuf, 0, tripwireRead, 0, tripwireBytes);
      ctx.device.queue.submit([encoder.finish()]);
    });

    await Promise.all([
      outRead.mapAsync(GPUMapMode.READ),
      tripwireRead.mapAsync(GPUMapMode.READ),
    ]);

    const outputSlice = outRead.getMappedRange().slice(0);
    const tw = new Uint32Array(tripwireRead.getMappedRange().slice(0));
    outRead.unmap();
    tripwireRead.unmap();

    const telemetry = {
      tripped: tw[0] !== 0,
      totalIterations: tw[1],
      maxIterationsPerThread: tw[2],
      offendingLoopId: tw[3],
      offendingInvocation: [tw[4], tw[5], tw[6]],
      ceilingTriggered: tw[7],
      invocationsExecuted: tw[8],
      maxLoopIterations,
      maxThreadIterations,
      loopCount: instrumented.loopCount,
    };

    if (telemetry.invocationsExecuted === 0) {
      throw new GpuValidationError(
        `Zero compute invocations executed in "${label}" (entryPoint="${entryPoint}"); dispatch was a no-op.`,
        { label, entryPoint, telemetry }
      );
    }

    if (telemetry.tripped) {
      throw new ShaderLoopTripwireError(
        `Shader loop tripwire exceeded in "${label}": loop #${telemetry.offendingLoopId} ` +
          `at invocation (${telemetry.offendingInvocation.join(', ')}) exceeded ` +
          `ceiling=${telemetry.ceilingTriggered} (observed ${telemetry.maxIterationsPerThread} iterations)`,
        telemetry
      );
    }

    return { telemetry, outputBuffer: outputSlice };
  } finally {
    if (ownsOutBuf) outBuf.destroy();
    outRead.destroy();
    tripwireBuf.destroy();
    tripwireRead.destroy();
  }
}

const SUPPORTED_ARG_TYPES = new Set(['f32', 'u32', 'i32']);
const RETURN_TYPE_LAYOUTS = {
  f32: { wgslType: 'f32', components: 1, strideLanes: 1, scalar: 'f32' },
  u32: { wgslType: 'u32', components: 1, strideLanes: 1, scalar: 'u32' },
  i32: { wgslType: 'i32', components: 1, strideLanes: 1, scalar: 'i32' },
  'vec2<f32>': { wgslType: 'vec2<f32>', components: 2, strideLanes: 2, scalar: 'f32' },
  vec2f: { wgslType: 'vec2<f32>', components: 2, strideLanes: 2, scalar: 'f32' },
  'vec3<f32>': { wgslType: 'vec3<f32>', components: 3, strideLanes: 4, scalar: 'f32' },
  vec3f: { wgslType: 'vec3<f32>', components: 3, strideLanes: 4, scalar: 'f32' },
  'vec4<f32>': { wgslType: 'vec4<f32>', components: 4, strideLanes: 4, scalar: 'f32' },
  vec4f: { wgslType: 'vec4<f32>', components: 4, strideLanes: 4, scalar: 'f32' },
  'vec2<u32>': { wgslType: 'vec2<u32>', components: 2, strideLanes: 2, scalar: 'u32' },
  vec2u: { wgslType: 'vec2<u32>', components: 2, strideLanes: 2, scalar: 'u32' },
  'vec3<u32>': { wgslType: 'vec3<u32>', components: 3, strideLanes: 4, scalar: 'u32' },
  vec3u: { wgslType: 'vec3<u32>', components: 3, strideLanes: 4, scalar: 'u32' },
  'vec4<u32>': { wgslType: 'vec4<u32>', components: 4, strideLanes: 4, scalar: 'u32' },
  vec4u: { wgslType: 'vec4<u32>', components: 4, strideLanes: 4, scalar: 'u32' },
  'vec2<i32>': { wgslType: 'vec2<i32>', components: 2, strideLanes: 2, scalar: 'i32' },
  vec2i: { wgslType: 'vec2<i32>', components: 2, strideLanes: 2, scalar: 'i32' },
  'vec3<i32>': { wgslType: 'vec3<i32>', components: 3, strideLanes: 4, scalar: 'i32' },
  vec3i: { wgslType: 'vec3<i32>', components: 3, strideLanes: 4, scalar: 'i32' },
  'vec4<i32>': { wgslType: 'vec4<i32>', components: 4, strideLanes: 4, scalar: 'i32' },
  vec4i: { wgslType: 'vec4<i32>', components: 4, strideLanes: 4, scalar: 'i32' },
};

export async function evalWgslBatch(
  ctx,
  { preamble = '', argTypes = ['f32'], returnType = 'f32', body, inputs = [] }
) {
  for (const t of argTypes) {
    if (!SUPPORTED_ARG_TYPES.has(t)) {
      throw new TypeError(`Unsupported argType "${t}" in evalWgslBatch; supported: ${Array.from(SUPPORTED_ARG_TYPES).join(', ')}`);
    }
  }
  const retLayout = RETURN_TYPE_LAYOUTS[returnType.replace(/\s+/g, '')];
  if (!retLayout) {
    throw new TypeError(`Unsupported returnType "${returnType}" in evalWgslBatch`);
  }
  if (inputs.length === 0) return [];

  const count = inputs.length;
  const argCount = argTypes.length;
  const strideLanes = Math.max(4, Math.ceil(Math.max(1, argCount) / 4) * 4);
  const stagingBuffer = new ArrayBuffer(count * strideLanes * 4);
  const f32View = new Float32Array(stagingBuffer);
  const u32View = new Uint32Array(stagingBuffer);
  const i32View = new Int32Array(stagingBuffer);

  for (let i = 0; i < count; i++) {
    const row = Array.isArray(inputs[i]) ? inputs[i] : [inputs[i]];
    for (let j = 0; j < argCount; j++) {
      const idx = i * strideLanes + j;
      const val = Number(row[j] ?? 0);
      if (argTypes[j] === 'u32') {
        u32View[idx] = val >>> 0;
      } else if (argTypes[j] === 'i32') {
        i32View[idx] = val | 0;
      } else {
        f32View[idx] = val;
      }
    }
  }

  const argDecls = argTypes.map((t, j) => `arg${j}: ${t}`).join(', ');
  const argLoads = argTypes
    .map((t, j) => {
      const raw = `inBuf[idx * ${strideLanes}u + ${j}u]`;
      return t === 'u32' ? raw : t === 'i32' ? `bitcast<i32>(${raw})` : `bitcast<f32>(${raw})`;
    })
    .join(', ');

  const wgsl = `
    ${preamble}

    fn _sh_eval_fn(${argDecls}) -> ${retLayout.wgslType} {
      ${body}
    }

    @group(0) @binding(0) var<storage, read> inBuf: array<u32>;
    @group(0) @binding(1) var<storage, read_write> outBuf: array<${retLayout.wgslType}>;

    @compute @workgroup_size(64)
    fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
      let idx = gid.x;
      if (idx >= ${count}u) { return; }
      let _sh_keep_in = inBuf[0];
      outBuf[idx] = _sh_eval_fn(${argLoads});
    }
  `;

  const module = await ctx.compileShaderModule({ label: 'eval-wgsl-batch', code: wgsl });

  const inBytes = stagingBuffer.byteLength;
  const outBytes = count * retLayout.strideLanes * 4;
  const inGpu = ctx.device.createBuffer({
    size: inBytes,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
  });
  const outGpu = ctx.device.createBuffer({
    size: outBytes,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
  });
  const outRead = ctx.device.createBuffer({
    size: outBytes,
    usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
  });

  try {
    await withGpuErrorScopes(ctx.device, 'evalWgslBatch', async () => {
      const pipeline = ctx.device.createComputePipeline({
        label: 'eval-wgsl-batch-pipeline',
        layout: 'auto',
        compute: { module, entryPoint: 'main' },
      });
      ctx.device.queue.writeBuffer(inGpu, 0, u32View);
      const bg = ctx.device.createBindGroup({
        layout: pipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: inGpu } },
          { binding: 1, resource: { buffer: outGpu } },
        ],
      });
      const encoder = ctx.device.createCommandEncoder();
      const pass = encoder.beginComputePass({ label: 'eval-wgsl-batch-pass' });
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bg);
      pass.dispatchWorkgroups(Math.ceil(count / 64));
      pass.end();
      encoder.copyBufferToBuffer(outGpu, 0, outRead, 0, outBytes);
      ctx.device.queue.submit([encoder.finish()]);
    });

    await outRead.mapAsync(GPUMapMode.READ);
    const slice = outRead.getMappedRange().slice(0);
    outRead.unmap();

    const typed =
      retLayout.scalar === 'u32'
        ? new Uint32Array(slice)
        : retLayout.scalar === 'i32'
          ? new Int32Array(slice)
          : new Float32Array(slice);

    if (retLayout.components === 1) {
      return Array.from(typed);
    }
    const results = [];
    for (let i = 0; i < count; i++) {
      const base = i * retLayout.strideLanes;
      results.push(Array.from(typed.slice(base, base + retLayout.components)));
    }
    return results;
  } finally {
    inGpu.destroy();
    outGpu.destroy();
    outRead.destroy();
  }
}
