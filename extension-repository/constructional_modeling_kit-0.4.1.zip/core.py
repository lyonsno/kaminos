from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass
from math import cos, isfinite, pi, sin, sqrt
from typing import Callable, Mapping


IdFactory = Callable[[str], str]

IDENTITY_KEYS = (
    "cmk_schema_version",
    "cmk_lineage_id",
    "cmk_construction_id",
    "cmk_instance_id",
    "cmk_variant",
)


def topology_fingerprint(
    *,
    vertex_count: int,
    faces: tuple[tuple[int, ...], ...],
) -> str:
    if vertex_count < 0:
        raise ValueError("vertex count cannot be negative")
    digest = hashlib.sha256(f"cmk-topology-v1|{vertex_count}|".encode())
    for face in faces:
        if len(face) < 3:
            raise ValueError("topology faces require at least three vertices")
        if any(index < 0 or index >= vertex_count for index in face):
            raise ValueError("topology face index is outside the vertex range")
        digest.update(",".join(str(index) for index in face).encode())
        digest.update(b";")
    return digest.hexdigest()


@dataclass(frozen=True)
class CollectionSpec:
    path: tuple[str, ...]


@dataclass(frozen=True)
class MaterialSpec:
    name: str
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class MarkerSpec:
    role: str
    label: str
    collection_path: tuple[str, ...]
    display_type: str
    color: tuple[float, float, float, float]
    size: float


@dataclass(frozen=True)
class SourceObject:
    name: str
    construction_id: str
    instance_id: str
    lineage_id: str
    parent_name: str | None = None


@dataclass(frozen=True)
class SiblingObject:
    source_name: str
    name: str
    construction_id: str
    source_instance_id: str
    instance_id: str
    lineage_id: str
    variant: str
    parent_name: str | None = None


Vec3 = tuple[float, float, float]


@dataclass(frozen=True)
class SelectedMuscleEndpoints:
    origin: Vec3
    insertion: Vec3
    strategy: str


@dataclass(frozen=True)
class MuscleBuildSpec:
    origin: Vec3
    belly: Vec3
    insertion: Vec3
    origin_width: float
    origin_depth: float
    belly_width: float
    belly_depth: float
    insertion_width: float
    insertion_depth: float
    origin_up: Vec3 | None = None
    belly_up: Vec3 | None = None
    insertion_up: Vec3 | None = None
    origin_tendon_fraction: float = 0.18
    insertion_tendon_fraction: float = 0.18
    rings: int = 25
    sides: int = 12


@dataclass(frozen=True)
class MuscleMesh:
    vertices: tuple[Vec3, ...]
    faces: tuple[tuple[int, ...], ...]
    face_regions: tuple[str, ...]
    ring_centers: tuple[Vec3, ...]


@dataclass(frozen=True)
class AttachmentSample:
    position: Vec3
    normal: Vec3
    radius: float
    source_object: str
    source_instance_id: str = ""
    face_index: int = -1
    source_vertex_count: int = 0
    source_polygon_count: int = 0


@dataclass(frozen=True)
class AttachmentFieldProfile:
    center: Vec3
    normal: Vec3
    span_axis: Vec3
    width: float
    depth: float
    sample_count: int


@dataclass(frozen=True)
class PatchMuscleBuildSpec:
    origin_samples: tuple[AttachmentSample, ...]
    insertion_samples: tuple[AttachmentSample, ...]
    thickness: float
    belly_scale: float = 1.15
    bulge: float = 0.0
    origin_tendon_fraction: float = 0.12
    insertion_tendon_fraction: float = 0.20
    rings: int = 25
    sides: int = 12


@dataclass(frozen=True)
class AttachmentTransferAssessment:
    status: str
    distance_ratio: float
    normal_alignment: float
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class RecoveredMuscleProfile:
    position: Vec3
    width: float
    depth: float
    normal: Vec3
    binormal: Vec3


@dataclass(frozen=True)
class MuscleRenamePlan:
    old_label: str
    new_label: str


ROOT_COLLECTION = "Constructional Model"
SEMANTICS_COLLECTION = "90 Semantics"

COLLECTION_SPECS: tuple[CollectionSpec, ...] = tuple(
    CollectionSpec(path)
    for path in (
        (ROOT_COLLECTION,),
        (ROOT_COLLECTION, "00 Reference"),
        (ROOT_COLLECTION, "10 Structure"),
        (ROOT_COLLECTION, "20 Muscle"),
        (ROOT_COLLECTION, "30 Tendon + Constraint"),
        (ROOT_COLLECTION, "40 Envelope"),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION, "Joint Frames"),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION, "Clearance Volumes"),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION, "Attachment Patches"),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION, "Segment Axes"),
        (ROOT_COLLECTION, SEMANTICS_COLLECTION, "Support Targets"),
    )
)

MATERIAL_SPECS: tuple[MaterialSpec, ...] = (
    MaterialSpec("CMK | Structure", (0.62, 0.49, 0.30, 1.0)),
    MaterialSpec("CMK | Muscle", (0.55, 0.055, 0.075, 1.0)),
    MaterialSpec("CMK | Tendon", (0.80, 0.54, 0.08, 1.0)),
    MaterialSpec("CMK | Constraint", (0.23, 0.48, 0.52, 1.0)),
    MaterialSpec("CMK | Envelope", (0.18, 0.31, 0.43, 0.34)),
    MaterialSpec("CMK | Joint Frame", (0.02, 0.72, 0.86, 1.0)),
    MaterialSpec("CMK | Clearance", (0.98, 0.72, 0.08, 0.42)),
    MaterialSpec("CMK | Attachment", (0.83, 0.15, 0.50, 1.0)),
    MaterialSpec("CMK | Segment Axis", (0.20, 0.70, 0.31, 1.0)),
    MaterialSpec("CMK | Support Target", (0.95, 0.30, 0.055, 1.0)),
)

_SEMANTIC_ROOT = (ROOT_COLLECTION, SEMANTICS_COLLECTION)
MARKER_SPECS: Mapping[str, MarkerSpec] = {
    "joint_frame": MarkerSpec(
        role="joint_frame",
        label="Joint Frame",
        collection_path=(*_SEMANTIC_ROOT, "Joint Frames"),
        display_type="ARROWS",
        color=(0.02, 0.72, 0.86, 1.0),
        size=0.20,
    ),
    "clearance_volume": MarkerSpec(
        role="clearance_volume",
        label="Clearance Volume",
        collection_path=(*_SEMANTIC_ROOT, "Clearance Volumes"),
        display_type="SPHERE",
        color=(0.98, 0.72, 0.08, 0.42),
        size=0.25,
    ),
    "attachment_patch": MarkerSpec(
        role="attachment_patch",
        label="Attachment Patch",
        collection_path=(*_SEMANTIC_ROOT, "Attachment Patches"),
        display_type="CIRCLE",
        color=(0.83, 0.15, 0.50, 1.0),
        size=0.16,
    ),
    "segment_axis": MarkerSpec(
        role="segment_axis",
        label="Segment Axis",
        collection_path=(*_SEMANTIC_ROOT, "Segment Axes"),
        display_type="SINGLE_ARROW",
        color=(0.20, 0.70, 0.31, 1.0),
        size=0.30,
    ),
    "support_target": MarkerSpec(
        role="support_target",
        label="Support Target",
        collection_path=(*_SEMANTIC_ROOT, "Support Targets"),
        display_type="CONE",
        color=(0.95, 0.30, 0.055, 1.0),
        size=0.20,
    ),
}

MUSCLE_COMPONENT_ROLES = {
    "rig": "muscle_rig",
    "surface": "muscle_surface_provisional",
    "path": "muscle_path",
    "origin": "attachment_origin",
    "belly": "belly_profile",
    "insertion": "attachment_insertion",
    "wrap": "wrap_guide",
    "frozen": "muscle_surface_frozen",
}

_GENERIC_OBJECT_NAME = re.compile(
    r"^(?:cube|mesh|object|empty|sphere|cylinder|plane|cone)(?:\.\d{3})?$",
    re.IGNORECASE,
)


def resolve_selected_muscle_endpoints(
    *,
    origin_object: Vec3,
    insertion_object: Vec3,
    origin_geometry: Vec3,
    insertion_geometry: Vec3,
) -> SelectedMuscleEndpoints:
    if _length(_subtract(insertion_object, origin_object)) > 1.0e-6:
        return SelectedMuscleEndpoints(
            origin=origin_object,
            insertion=insertion_object,
            strategy="object_origins",
        )
    if _length(_subtract(insertion_geometry, origin_geometry)) > 1.0e-6:
        return SelectedMuscleEndpoints(
            origin=origin_geometry,
            insertion=insertion_geometry,
            strategy="geometry_centers",
        )
    raise ValueError(
        muscle_endpoint_failure_message(
            route="selected_objects",
            strategy="geometry_centers",
            stage="endpoint_resolution",
            origin=origin_geometry,
            insertion=insertion_geometry,
        )
    )


def muscle_endpoint_failure_message(
    *,
    route: str,
    strategy: str,
    stage: str,
    origin: Vec3,
    insertion: Vec3,
) -> str:
    def format_vector(value: Vec3) -> str:
        return "(" + ", ".join(f"{component:.9g}" for component in value) + ")"

    distance = _length(_subtract(insertion, origin))
    return (
        "origin and insertion must be distinct "
        f"[route={route} strategy={strategy} stage={stage} "
        f"origin={format_vector(origin)} insertion={format_vector(insertion)} "
        f"distance={distance:.9g}]"
    )


def _add(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _subtract(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _scale(value: Vec3, amount: float) -> Vec3:
    return (value[0] * amount, value[1] * amount, value[2] * amount)


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _length(value: Vec3) -> float:
    return sqrt(_dot(value, value))


def _normalize(value: Vec3) -> Vec3:
    length = _length(value)
    if length <= 1.0e-9:
        raise ValueError("muscle path contains a collapsed tangent")
    return _scale(value, 1.0 / length)


def _lerp(start: float, end: float, amount: float) -> float:
    return start + (end - start) * amount


def _lerp_vector(start: Vec3, end: Vec3, amount: float) -> Vec3:
    return (
        _lerp(start[0], end[0], amount),
        _lerp(start[1], end[1], amount),
        _lerp(start[2], end[2], amount),
    )


def _smoothstep(amount: float) -> float:
    clamped = min(max(amount, 0.0), 1.0)
    return clamped * clamped * (3.0 - 2.0 * clamped)


def _deterministic_direction(value: Vec3) -> Vec3:
    direction = _normalize(value)
    dominant = max(range(3), key=lambda axis: abs(direction[axis]))
    return _scale(direction, -1.0) if direction[dominant] < 0.0 else direction


def fit_attachment_field(
    samples: tuple[AttachmentSample, ...],
    *,
    path_direction: Vec3,
) -> AttachmentFieldProfile:
    if not samples:
        raise ValueError("attachment field requires at least one authored sample")
    path = _normalize(path_direction)
    for sample in samples:
        values = (*sample.position, *sample.normal, sample.radius)
        if not all(isfinite(value) for value in values):
            raise ValueError("attachment samples must be finite")
        if sample.radius <= 0.0:
            raise ValueError("attachment sample radius must be positive")
        if _length(sample.normal) <= 1.0e-9:
            raise ValueError("attachment sample normal must be nonzero")

    count = len(samples)
    center = tuple(
        sum(sample.position[axis] for sample in samples) / count
        for axis in range(3)
    )
    normal_sum = tuple(
        sum(_normalize(sample.normal)[axis] for sample in samples)
        for axis in range(3)
    )
    if _length(normal_sum) <= 1.0e-7:
        raise ValueError("attachment field normals cancel without a stable surface side")
    normal = _normalize(normal_sum)

    projected_offsets = tuple(
        _subtract(
            _subtract(sample.position, center),
            _scale(path, _dot(_subtract(sample.position, center), path)),
        )
        for sample in samples
    )
    widest = max(projected_offsets, key=_length)
    if _length(widest) <= 1.0e-7:
        surface_tangent = _cross(normal, path)
        if _length(surface_tangent) <= 1.0e-7:
            surface_tangent = _initial_frame(path)[0]
        span_axis = _deterministic_direction(surface_tangent)
    else:
        span_axis = _deterministic_direction(widest)
    depth_axis = _normalize(_cross(path, span_axis))

    width = max(
        abs(_dot(_subtract(sample.position, center), span_axis)) + sample.radius
        for sample in samples
    )
    depth = max(
        abs(_dot(_subtract(sample.position, center), depth_axis)) + sample.radius
        for sample in samples
    )
    return AttachmentFieldProfile(
        center=center,
        normal=normal,
        span_axis=span_axis,
        width=width,
        depth=depth,
        sample_count=count,
    )


def assess_attachment_transfer(
    *,
    original_position: Vec3,
    original_normal: Vec3,
    candidate_position: Vec3,
    candidate_normal: Vec3,
    reference_scale: float,
    quiet_distance_ratio: float = 0.05,
    quiet_normal_alignment: float = 0.25,
) -> AttachmentTransferAssessment:
    values = (
        *original_position,
        *original_normal,
        *candidate_position,
        *candidate_normal,
        reference_scale,
        quiet_distance_ratio,
        quiet_normal_alignment,
    )
    if not all(isfinite(value) for value in values):
        raise ValueError("attachment transfer evidence must be finite")
    if reference_scale <= 0.0:
        raise ValueError("attachment transfer reference scale must be positive")
    if quiet_distance_ratio < 0.0:
        raise ValueError("quiet attachment distance ratio must not be negative")
    if not -1.0 <= quiet_normal_alignment <= 1.0:
        raise ValueError("quiet attachment normal alignment must be in [-1, 1]")

    original_direction = _normalize(original_normal)
    candidate_direction = _normalize(candidate_normal)
    distance_ratio = _length(
        _subtract(candidate_position, original_position)
    ) / reference_scale
    normal_alignment = _dot(original_direction, candidate_direction)
    reasons: list[str] = []
    if distance_ratio > quiet_distance_ratio:
        reasons.append("distance")
    if normal_alignment < quiet_normal_alignment:
        reasons.append("normal")
    return AttachmentTransferAssessment(
        status="UNCERTAIN" if reasons else "STABLE",
        distance_ratio=distance_ratio,
        normal_alignment=normal_alignment,
        reasons=tuple(reasons),
    )


def _quadratic_path(spec: MuscleBuildSpec, amount: float) -> tuple[Vec3, Vec3]:
    control = _subtract(
        _scale(spec.belly, 2.0),
        _scale(_add(spec.origin, spec.insertion), 0.5),
    )
    inverse = 1.0 - amount
    point = _add(
        _add(
            _scale(spec.origin, inverse * inverse),
            _scale(control, 2.0 * inverse * amount),
        ),
        _scale(spec.insertion, amount * amount),
    )
    tangent = _add(
        _scale(_subtract(control, spec.origin), 2.0 * inverse),
        _scale(_subtract(spec.insertion, control), 2.0 * amount),
    )
    return point, tangent


def _profile_dimensions(spec: MuscleBuildSpec, amount: float) -> tuple[float, float]:
    if amount <= spec.origin_tendon_fraction:
        return spec.origin_width, spec.origin_depth
    if amount <= 0.5:
        blend = _smoothstep(
            (amount - spec.origin_tendon_fraction)
            / (0.5 - spec.origin_tendon_fraction),
        )
        return (
            _lerp(spec.origin_width, spec.belly_width, blend),
            _lerp(spec.origin_depth, spec.belly_depth, blend),
        )

    insertion_start = 1.0 - spec.insertion_tendon_fraction
    if amount < insertion_start:
        blend = _smoothstep(
            (amount - 0.5) / (insertion_start - 0.5),
        )
        return (
            _lerp(spec.belly_width, spec.insertion_width, blend),
            _lerp(spec.belly_depth, spec.insertion_depth, blend),
        )
    return spec.insertion_width, spec.insertion_depth


def _validate_muscle_spec(spec: MuscleBuildSpec) -> None:
    points = (*spec.origin, *spec.belly, *spec.insertion)
    dimensions = (
        spec.origin_width,
        spec.origin_depth,
        spec.belly_width,
        spec.belly_depth,
        spec.insertion_width,
        spec.insertion_depth,
    )
    if not all(isfinite(value) for value in (*points, *dimensions)):
        raise ValueError("muscle source values must be finite")
    authored_axes = tuple(
        axis
        for axis in (spec.origin_up, spec.belly_up, spec.insertion_up)
        if axis is not None
    )
    if authored_axes and len(authored_axes) != 3:
        raise ValueError("muscle profile orientation requires all three authored axes")
    if any(
        not all(isfinite(value) for value in axis) or _length(axis) <= 1.0e-9
        for axis in authored_axes
    ):
        raise ValueError("muscle profile orientation axes must be finite and nonzero")
    if _length(_subtract(spec.insertion, spec.origin)) <= 1.0e-6:
        raise ValueError("origin and insertion must be distinct")
    if _length(_subtract(spec.belly, spec.origin)) <= 1.0e-6:
        raise ValueError("belly must be distinct from origin")
    if _length(_subtract(spec.insertion, spec.belly)) <= 1.0e-6:
        raise ValueError("belly must be distinct from insertion")
    if any(value <= 0.0 for value in dimensions):
        raise ValueError("muscle profile dimensions must be positive")
    if spec.rings < 5 or spec.rings % 2 == 0:
        raise ValueError("muscle ring count must be an odd value of at least five")
    if spec.sides < 4:
        raise ValueError("muscle side count must be at least four")
    if not 0.0 < spec.origin_tendon_fraction < 0.5:
        raise ValueError("origin tendon fraction must be between zero and one half")
    if not 0.0 < spec.insertion_tendon_fraction < 0.5:
        raise ValueError("insertion tendon fraction must be between zero and one half")


def _initial_frame(tangent: Vec3) -> tuple[Vec3, Vec3]:
    reference = min(
        ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
        key=lambda axis: abs(_dot(tangent, axis)),
    )
    normal = _normalize(_cross(tangent, reference))
    return normal, _normalize(_cross(tangent, normal))


def _authored_profile_normal(
    spec: MuscleBuildSpec,
    amount: float,
    tangent: Vec3,
) -> Vec3 | None:
    if spec.origin_up is None or spec.belly_up is None or spec.insertion_up is None:
        return None
    if amount <= 0.5:
        authored = _lerp_vector(spec.origin_up, spec.belly_up, amount * 2.0)
    else:
        authored = _lerp_vector(
            spec.belly_up,
            spec.insertion_up,
            (amount - 0.5) * 2.0,
        )
    projected = _subtract(authored, _scale(tangent, _dot(authored, tangent)))
    if _length(projected) <= 1.0e-7:
        return None
    return _normalize(projected)


def build_muscle_mesh(spec: MuscleBuildSpec) -> MuscleMesh:
    _validate_muscle_spec(spec)

    ring_centers: list[Vec3] = []
    vertices: list[Vec3] = []
    previous_normal: Vec3 | None = None

    for ring_index in range(spec.rings):
        amount = ring_index / (spec.rings - 1)
        center, raw_tangent = _quadratic_path(spec, amount)
        tangent = _normalize(raw_tangent)
        ring_centers.append(center)

        authored_normal = _authored_profile_normal(spec, amount, tangent)
        if authored_normal is not None:
            normal = authored_normal
            binormal = _normalize(_cross(tangent, normal))
        elif previous_normal is None:
            normal, binormal = _initial_frame(tangent)
        else:
            transported = _subtract(
                previous_normal,
                _scale(tangent, _dot(previous_normal, tangent)),
            )
            if _length(transported) <= 1.0e-7:
                normal, binormal = _initial_frame(tangent)
            else:
                normal = _normalize(transported)
                binormal = _normalize(_cross(tangent, normal))
        previous_normal = normal

        width, depth = _profile_dimensions(spec, amount)
        for side_index in range(spec.sides):
            angle = 2.0 * pi * side_index / spec.sides
            vertex = _add(
                center,
                _add(
                    _scale(normal, cos(angle) * width),
                    _scale(binormal, sin(angle) * depth),
                ),
            )
            vertices.append(vertex)

    faces: list[tuple[int, ...]] = []
    regions: list[str] = []
    faces.append(tuple(reversed(range(spec.sides))))
    regions.append("attachment_origin")

    for ring_index in range(spec.rings - 1):
        segment_midpoint = (ring_index + 0.5) / (spec.rings - 1)
        if segment_midpoint <= spec.origin_tendon_fraction:
            region = "tendon_origin"
        elif segment_midpoint >= 1.0 - spec.insertion_tendon_fraction:
            region = "tendon_insertion"
        else:
            region = "muscle_belly"

        current = ring_index * spec.sides
        following = (ring_index + 1) * spec.sides
        for side_index in range(spec.sides):
            next_side = (side_index + 1) % spec.sides
            faces.append(
                (
                    current + side_index,
                    current + next_side,
                    following + next_side,
                    following + side_index,
                ),
            )
            regions.append(region)

    final_ring = (spec.rings - 1) * spec.sides
    faces.append(tuple(final_ring + side for side in range(spec.sides)))
    regions.append("attachment_insertion")

    return MuscleMesh(
        vertices=tuple(vertices),
        faces=tuple(faces),
        face_regions=tuple(regions),
        ring_centers=tuple(ring_centers),
    )


def build_patch_muscle_mesh(spec: PatchMuscleBuildSpec) -> MuscleMesh:
    scalar_values = (
        spec.thickness,
        spec.belly_scale,
        spec.bulge,
        spec.origin_tendon_fraction,
        spec.insertion_tendon_fraction,
    )
    if not all(isfinite(value) for value in scalar_values):
        raise ValueError("patch muscle settings must be finite")
    if spec.thickness <= 0.0:
        raise ValueError("patch muscle thickness must be positive")
    if spec.belly_scale <= 0.0:
        raise ValueError("patch muscle belly scale must be positive")
    if not spec.origin_samples or not spec.insertion_samples:
        raise ValueError("patch muscle requires painted Origin and Insertion fields")

    origin_center = tuple(
        sum(sample.position[axis] for sample in spec.origin_samples)
        / len(spec.origin_samples)
        for axis in range(3)
    )
    insertion_center = tuple(
        sum(sample.position[axis] for sample in spec.insertion_samples)
        / len(spec.insertion_samples)
        for axis in range(3)
    )
    path = _subtract(insertion_center, origin_center)
    if _length(path) <= 1.0e-6:
        raise ValueError("painted Origin and Insertion centers must be distinct")
    path_direction = _normalize(path)
    origin = fit_attachment_field(
        spec.origin_samples,
        path_direction=path_direction,
    )
    insertion = fit_attachment_field(
        spec.insertion_samples,
        path_direction=path_direction,
    )

    combined_normal = _add(origin.normal, insertion.normal)
    bulge_direction = _subtract(
        combined_normal,
        _scale(path_direction, _dot(combined_normal, path_direction)),
    )
    if _length(bulge_direction) <= 1.0e-7:
        bulge_direction = _initial_frame(path_direction)[1]
    else:
        bulge_direction = _normalize(bulge_direction)
    midpoint = _scale(_add(origin.center, insertion.center), 0.5)
    belly = _add(midpoint, _scale(bulge_direction, spec.bulge))

    belly_axis = _add(origin.span_axis, insertion.span_axis)
    if _length(belly_axis) <= 1.0e-7:
        belly_axis = origin.span_axis
    belly_axis = _deterministic_direction(
        _subtract(
            belly_axis,
            _scale(path_direction, _dot(belly_axis, path_direction)),
        )
    )
    origin_depth = max(origin.depth, spec.thickness)
    insertion_depth = max(insertion.depth, spec.thickness)
    return build_muscle_mesh(
        MuscleBuildSpec(
            origin=origin.center,
            belly=belly,
            insertion=insertion.center,
            origin_width=max(origin.width, spec.thickness),
            origin_depth=origin_depth,
            belly_width=max(origin.width, insertion.width) * spec.belly_scale,
            belly_depth=max(origin_depth, insertion_depth) * spec.belly_scale,
            insertion_width=max(insertion.width, spec.thickness),
            insertion_depth=insertion_depth,
            origin_up=origin.span_axis,
            belly_up=belly_axis,
            insertion_up=insertion.span_axis,
            origin_tendon_fraction=spec.origin_tendon_fraction,
            insertion_tendon_fraction=spec.insertion_tendon_fraction,
            rings=spec.rings,
            sides=spec.sides,
        )
    )


def classify_muscle_recovery(
    *,
    present_components: set[str],
    conflicting_components: set[str],
    surface_profile_valid: bool,
) -> str:
    required = {"surface", "path", "origin", "belly", "insertion"}
    handles = {"origin", "belly", "insertion"}
    present = set(present_components) & required
    conflicts = set(conflicting_components) & required
    if conflicts:
        return "remake_required"
    if present == required:
        return "refreshable"

    missing = required - present
    if missing & handles:
        return "reconstructible" if surface_profile_valid else "remake_required"
    if handles <= present:
        return "reconstructible"
    return "remake_required"


def recover_muscle_profiles(
    vertices: tuple[Vec3, ...],
    *,
    rings: int,
    sides: int,
) -> tuple[RecoveredMuscleProfile, RecoveredMuscleProfile, RecoveredMuscleProfile]:
    if rings < 5 or rings % 2 == 0:
        raise ValueError("recoverable muscle ring count must be odd and at least five")
    if sides < 4:
        raise ValueError("recoverable muscle profile requires at least four sides")
    if len(vertices) != rings * sides:
        raise ValueError(
            f"surface topology does not match {rings} rings x {sides} sides"
        )
    if any(not isfinite(value) for vertex in vertices for value in vertex):
        raise ValueError("recoverable muscle surface vertices must be finite")

    profiles: list[RecoveredMuscleProfile] = []
    for ring_index in (0, rings // 2, rings - 1):
        start = ring_index * sides
        ring = vertices[start:start + sides]
        position = tuple(
            sum(vertex[axis] for vertex in ring) / sides
            for axis in range(3)
        )
        width_vector = _subtract(ring[0], position)
        width = _length(width_vector)
        if width <= 1.0e-7:
            raise ValueError(f"surface ring {ring_index} has collapsed width")
        normal = _normalize(width_vector)

        depth_index = max(
            range(1, sides),
            key=lambda index: abs(sin(2.0 * pi * index / sides)),
        )
        angle = 2.0 * pi * depth_index / sides
        sample_vector = _subtract(ring[depth_index], position)
        residual = _subtract(
            sample_vector,
            _scale(normal, _dot(sample_vector, normal)),
        )
        sine = sin(angle)
        if abs(sine) <= 1.0e-7 or _length(residual) <= 1.0e-7:
            raise ValueError(f"surface ring {ring_index} has collapsed depth")
        depth = _length(residual) / abs(sine)
        binormal = _scale(_normalize(residual), 1.0 if sine > 0.0 else -1.0)
        profiles.append(
            RecoveredMuscleProfile(
                position=position,
                width=width,
                depth=depth,
                normal=normal,
                binormal=binormal,
            )
        )

    if any(
        _length(_subtract(profiles[first].position, profiles[second].position))
        <= 1.0e-6
        for first, second in ((0, 1), (1, 2), (0, 2))
    ):
        raise ValueError("recovered profile centers must be distinct")

    return profiles[0], profiles[1], profiles[2]


def slugify_label(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii").lower()
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_value).strip("-")
    if not slug:
        raise ValueError("label must contain at least one letter or number")
    return slug


def collection_path_action(
    name: str,
    *,
    child_exists: bool,
    global_exists: bool,
) -> str:
    if child_exists:
        return "reuse"
    if global_exists:
        raise ValueError(
            f"collection {name!r} exists outside the intended schema path"
        )
    return "create"


def ensure_source_identity(
    metadata: Mapping[str, str],
    *,
    construction_hint: str,
    lineage_id: str | None = None,
    id_factory: IdFactory,
) -> dict[str, str]:
    identity = {str(key): str(value) for key, value in metadata.items()}
    existing_keys = tuple(key for key in IDENTITY_KEYS if key in identity)
    if existing_keys:
        incomplete_keys = tuple(
            key
            for key in IDENTITY_KEYS
            if not identity.get(key)
        )
        if incomplete_keys:
            raise ValueError(
                "existing constructional identity is incomplete: "
                + ", ".join(incomplete_keys)
            )
        return identity

    identity["cmk_schema_version"] = "1"
    identity["cmk_lineage_id"] = lineage_id or id_factory("lineage")
    identity["cmk_construction_id"] = slugify_label(construction_hint)
    identity["cmk_instance_id"] = id_factory("instance")
    identity["cmk_variant"] = "parent"
    return identity


def prepare_source_identities(
    sources: tuple[tuple[str, Mapping[str, str]], ...],
    *,
    lineage_id: str,
    id_factory: IdFactory,
) -> tuple[dict[str, str], ...]:
    return tuple(
        ensure_source_identity(
            metadata,
            construction_hint=name,
            lineage_id=lineage_id,
            id_factory=id_factory,
        )
        for name, metadata in sources
    )


def sibling_candidate_names(
    source_names: tuple[str, ...],
    *,
    sibling_label: str,
) -> tuple[str, ...]:
    if not source_names:
        raise ValueError("at least one source object is required")
    if len(source_names) != len(set(source_names)):
        raise ValueError("source object names must be unique")

    variant = slugify_label(sibling_label)
    sibling_names = tuple(
        f"{source_name}.sibling.{variant}"
        for source_name in source_names
    )
    if len(sibling_names) != len(set(sibling_names)):
        raise ValueError("sibling object names must be unique")
    return sibling_names


def build_sibling_plan(
    sources: tuple[SourceObject, ...],
    *,
    sibling_label: str,
    id_factory: IdFactory,
) -> tuple[SiblingObject, ...]:
    source_names = tuple(source.name for source in sources)
    candidate_names = sibling_candidate_names(
        source_names,
        sibling_label=sibling_label,
    )

    lineages = {source.lineage_id for source in sources}
    if len(lineages) != 1 or not next(iter(lineages)):
        raise ValueError("all source objects must share one non-empty lineage")

    variant = slugify_label(sibling_label)
    sibling_names = dict(zip(source_names, candidate_names, strict=True))

    siblings: list[SiblingObject] = []
    for source in sources:
        if not source.construction_id:
            raise ValueError(f"source {source.name!r} has no construction identity")
        if not source.instance_id:
            raise ValueError(f"source {source.name!r} has no instance identity")

        parent_name = sibling_names.get(source.parent_name, source.parent_name)
        siblings.append(
            SiblingObject(
                source_name=source.name,
                name=sibling_names[source.name],
                construction_id=source.construction_id,
                source_instance_id=source.instance_id,
                instance_id=id_factory("instance"),
                lineage_id=source.lineage_id,
                variant=variant,
                parent_name=parent_name,
            )
        )

    return tuple(siblings)


def fork_offset_from_bounds(minimum_x: float, maximum_x: float) -> float:
    if maximum_x < minimum_x:
        raise ValueError("maximum bounds value must not be less than minimum")
    return max((maximum_x - minimum_x) * 1.25, 0.5)


def next_numbered_name(base: str, existing_names: set[str]) -> str:
    if base not in existing_names:
        return base
    number = 2
    while f"{base} {number:02d}" in existing_names:
        number += 1
    return f"{base} {number:02d}"


def normalize_muscle_label(value: str) -> str:
    label = " ".join(str(value).replace("|", " - ").split())
    if not label:
        raise ValueError("muscle name must not be blank")
    return label


def muscle_component_names(label: str) -> dict[str, str]:
    normalized = normalize_muscle_label(label)
    return {
        "rig": normalized,
        "surface": f"{normalized} | Surface",
        "path": f"{normalized} | Path",
        "origin": f"{normalized} | Origin",
        "belly": f"{normalized} | Belly",
        "insertion": f"{normalized} | Insertion",
    }


def _informative_source_name(value: str) -> str:
    name = " ".join(str(value).split())
    if not name or _GENERIC_OBJECT_NAME.fullmatch(name):
        return ""
    return name


def _provisional_muscle_base(origin_source: str, insertion_source: str) -> str:
    origin = _informative_source_name(origin_source)
    insertion = _informative_source_name(insertion_source)
    if origin and insertion and origin != insertion:
        return f"{origin} to {insertion}"
    if origin or insertion:
        return f"{origin or insertion} Muscle"
    return "Muscle"


def _muscle_label_available(label: str, occupied_names: set[str]) -> bool:
    return not set(muscle_component_names(label).values()) & occupied_names


def next_muscle_label(
    origin_source: str,
    insertion_source: str,
    occupied_names: set[str],
) -> str:
    base = normalize_muscle_label(
        _provisional_muscle_base(origin_source, insertion_source)
    )
    if _muscle_label_available(base, occupied_names):
        return base
    number = 2
    while not _muscle_label_available(f"{base} {number:02d}", occupied_names):
        number += 1
    return f"{base} {number:02d}"


def plan_muscle_renames(
    current_labels: tuple[str, ...],
    stem: str,
    occupied_names: set[str],
) -> tuple[MuscleRenamePlan, ...]:
    if not current_labels:
        raise ValueError("at least one muscle is required for batch naming")
    if len(current_labels) != len(set(current_labels)):
        raise ValueError("muscle labels must be unique")

    normalized_stem = normalize_muscle_label(stem)
    owned_names = {
        name
        for label in current_labels
        for name in muscle_component_names(label).values()
    }
    reserved = set(occupied_names) - owned_names
    plans: list[MuscleRenamePlan] = []

    if len(current_labels) == 1:
        candidate = normalized_stem
        number = 2
        while not _muscle_label_available(candidate, reserved):
            candidate = f"{normalized_stem} {number:02d}"
            number += 1
        return (MuscleRenamePlan(current_labels[0], candidate),)

    number = 1
    for old_label in current_labels:
        while True:
            candidate = f"{normalized_stem} {number:02d}"
            number += 1
            if _muscle_label_available(candidate, reserved):
                break
        plans.append(MuscleRenamePlan(old_label, candidate))
        reserved.update(muscle_component_names(candidate).values())
    return tuple(plans)
