from __future__ import annotations

import importlib
import json
import uuid

import bpy
from bpy.app.handlers import persistent
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras import view3d_utils
from mathutils import Matrix, Vector

from . import core
core = importlib.reload(core)


bl_info = {
    "name": "Constructional Modeling Kit",
    "author": "Noah Lyons and Poltergeist",
    "version": (0, 4, 1),
    "blender": (5, 1, 0),
    "location": "3D Viewport > Sidebar > Construction",
    "description": "Relationship-first anatomy authoring helpers",
    "category": "3D View",
}


IDENTITY_KEYS = core.IDENTITY_KEYS


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _identity_from_object(obj: bpy.types.Object) -> dict[str, str]:
    return {
        key: str(obj[key])
        for key in IDENTITY_KEYS
        if key in obj
    }


def _write_properties(obj: bpy.types.Object, values: dict[str, str]) -> None:
    for key, value in values.items():
        obj[key] = value


def _existing_lineage(objects: list[bpy.types.Object]) -> str | None:
    lineages = {
        str(obj["cmk_lineage_id"])
        for obj in objects
        if "cmk_lineage_id" in obj and str(obj["cmk_lineage_id"])
    }
    if len(lineages) > 1:
        raise ValueError("selection contains more than one constructional lineage")
    return next(iter(lineages), None)


def _ensure_collection_path(
    scene: bpy.types.Scene,
    path: tuple[str, ...],
) -> tuple[bpy.types.Collection, bool]:
    parent = scene.collection
    created_any = False

    for name in path:
        child = parent.children.get(name)
        if child is None:
            core.collection_path_action(
                name,
                child_exists=False,
                global_exists=bpy.data.collections.get(name) is not None,
            )
            child = bpy.data.collections.new(name)
            parent.children.link(child)
            created_any = True
        parent = child

    return parent, created_any


def _preflight_collection_paths(scene: bpy.types.Scene) -> None:
    for spec in core.COLLECTION_SPECS:
        parent = scene.collection
        for index, name in enumerate(spec.path):
            child = parent.children.get(name)
            core.collection_path_action(
                name,
                child_exists=child is not None,
                global_exists=bpy.data.collections.get(name) is not None,
            )
            if child is None:
                for pending_name in spec.path[index + 1:]:
                    core.collection_path_action(
                        pending_name,
                        child_exists=False,
                        global_exists=(
                            bpy.data.collections.get(pending_name) is not None
                        ),
                    )
                break
            parent = child


def _ensure_material(spec: core.MaterialSpec) -> bool:
    material = bpy.data.materials.get(spec.name)
    created = material is None
    if material is None:
        material = bpy.data.materials.new(spec.name)

    material.diffuse_color = spec.color
    material.metallic = 0.0
    material.roughness = 0.58
    return created


def _initialize_scene(scene: bpy.types.Scene) -> tuple[int, int]:
    _preflight_collection_paths(scene)

    created_collections = 0
    for spec in core.COLLECTION_SPECS:
        _, created = _ensure_collection_path(scene, spec.path)
        created_collections += int(created)

    created_materials = sum(
        int(_ensure_material(spec))
        for spec in core.MATERIAL_SPECS
    )
    scene["cmk_schema_version"] = "1"
    return created_collections, created_materials


def _prepare_parent_identities(
    objects: list[bpy.types.Object],
) -> tuple[str, tuple[dict[str, str], ...]]:
    lineage_id = _existing_lineage(objects) or _new_id("lineage")
    identities = core.prepare_source_identities(
        tuple(
            (obj.name, _identity_from_object(obj))
            for obj in objects
        ),
        lineage_id=lineage_id,
        id_factory=_new_id,
    )
    return lineage_id, identities


def _stamp_parent_objects(
    objects: list[bpy.types.Object],
    *,
    prepared: tuple[str, tuple[dict[str, str], ...]] | None = None,
) -> str:
    lineage_id, identities = prepared or _prepare_parent_identities(objects)
    for obj, identity in zip(objects, identities, strict=True):
        _write_properties(obj, identity)
    return lineage_id


def _source_records(
    objects: list[bpy.types.Object],
    *,
    identities: tuple[dict[str, str], ...] | None = None,
) -> tuple[core.SourceObject, ...]:
    metadata = identities or tuple(
        _identity_from_object(obj)
        for obj in objects
    )
    return tuple(
        core.SourceObject(
            name=obj.name,
            construction_id=identity.get("cmk_construction_id", ""),
            instance_id=identity.get("cmk_instance_id", ""),
            lineage_id=identity.get("cmk_lineage_id", ""),
            parent_name=obj.parent.name if obj.parent else None,
        )
        for obj, identity in zip(objects, metadata, strict=True)
    )


def _selection_x_bounds(objects: list[bpy.types.Object]) -> tuple[float, float]:
    x_values: list[float] = []
    for obj in objects:
        if obj.type == "EMPTY":
            x_values.append(float(obj.matrix_world.translation.x))
            continue
        x_values.extend(
            float((obj.matrix_world @ Vector(corner)).x)
            for corner in obj.bound_box
        )

    if not x_values:
        x_values = [float(obj.matrix_world.translation.x) for obj in objects]
    return min(x_values), max(x_values)


def _duplicate_sources(
    sources: list[bpy.types.Object],
    plans: tuple[core.SiblingObject, ...],
) -> dict[str, bpy.types.Object]:
    source_by_name = {obj.name: obj for obj in sources}
    duplicate_by_source: dict[str, bpy.types.Object] = {}

    for plan in plans:
        source = source_by_name[plan.source_name]
        duplicate = source.copy()
        if source.data is not None:
            duplicate.data = source.data.copy()
        duplicate.name = plan.name
        for collection in source.users_collection:
            collection.objects.link(duplicate)

        _write_properties(
            duplicate,
            {
                "cmk_schema_version": "1",
                "cmk_lineage_id": plan.lineage_id,
                "cmk_construction_id": plan.construction_id,
                "cmk_instance_id": plan.instance_id,
                "cmk_variant": plan.variant,
                "cmk_source_instance_id": plan.source_instance_id,
                "cmk_source_object_name": plan.source_name,
            },
        )
        duplicate_by_source[plan.source_name] = duplicate

    sibling_by_name = {
        plan.name: duplicate_by_source[plan.source_name]
        for plan in plans
    }
    for plan in plans:
        duplicate = duplicate_by_source[plan.source_name]
        if plan.parent_name not in sibling_by_name:
            continue
        world_transform = duplicate.matrix_world.copy()
        duplicate.parent = sibling_by_name[plan.parent_name]
        duplicate.matrix_world = world_transform

    return duplicate_by_source


class CMK_OT_initialize_scene(bpy.types.Operator):
    bl_idname = "cmk.initialize_scene"
    bl_label = "Initialize Constructional Scene"
    bl_description = "Create the collection and material schema without changing geometry or preferences"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            collections, materials = _initialize_scene(context.scene)
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Constructional scene initialized: {collections} collection paths, "
            f"{materials} materials created",
        )
        return {"FINISHED"}


class CMK_OT_stamp_parent(bpy.types.Operator):
    bl_idname = "cmk.stamp_parent"
    bl_label = "Stamp Selected as Parent"
    bl_description = "Assign stable construction, instance, lineage, and parent-variant identities"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and bool(context.selected_objects)

    def execute(self, context):
        objects = sorted(context.selected_objects, key=lambda obj: obj.name)
        try:
            lineage_id = _stamp_parent_objects(objects)
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Stamped {len(objects)} parent objects in {lineage_id}",
        )
        return {"FINISHED"}


class CMK_OT_fork_sibling(bpy.types.Operator):
    bl_idname = "cmk.fork_sibling"
    bl_label = "Fork Selected to Sibling"
    bl_description = "Create independent geometry with shared construction IDs and source-instance receipts"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and bool(context.selected_objects)

    def execute(self, context):
        sources = sorted(context.selected_objects, key=lambda obj: obj.name)
        active_source = context.view_layer.objects.active
        sibling_label = context.window_manager.cmk_sibling_label

        try:
            prepared_identities = _prepare_parent_identities(sources)
            plans = core.build_sibling_plan(
                _source_records(
                    sources,
                    identities=prepared_identities[1],
                ),
                sibling_label=sibling_label,
                id_factory=_new_id,
            )
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        collisions = [
            plan.name
            for plan in plans
            if bpy.data.objects.get(plan.name) is not None
        ]
        if collisions:
            self.report(
                {"ERROR"},
                "Sibling variant already exists; choose another label: "
                + ", ".join(collisions[:3]),
            )
            return {"CANCELLED"}

        _stamp_parent_objects(
            sources,
            prepared=prepared_identities,
        )

        minimum_x, maximum_x = _selection_x_bounds(sources)
        offset = core.fork_offset_from_bounds(minimum_x, maximum_x)
        duplicate_by_source = _duplicate_sources(sources, plans)

        source_names = {source.name for source in sources}
        for source in sources:
            if source.parent and source.parent.name in source_names:
                continue
            duplicate = duplicate_by_source[source.name]
            world_transform = duplicate.matrix_world.copy()
            world_transform.translation.x += offset
            duplicate.matrix_world = world_transform

        bpy.ops.object.select_all(action="DESELECT")
        for duplicate in duplicate_by_source.values():
            duplicate.select_set(True)
        if active_source and active_source.name in duplicate_by_source:
            context.view_layer.objects.active = duplicate_by_source[active_source.name]
        else:
            context.view_layer.objects.active = next(iter(duplicate_by_source.values()))

        self.report(
            {"INFO"},
            f"Forked {len(plans)} objects as {plans[0].variant}; "
            f"source construction IDs preserved",
        )
        return {"FINISHED"}


class CMK_OT_add_marker(bpy.types.Operator):
    bl_idname = "cmk.add_marker"
    bl_label = "Add Constructional Marker"
    bl_description = "Add a named semantic marker at the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}

    marker_kind: EnumProperty(
        name="Marker",
        items=tuple(
            (key, spec.label, f"Add {spec.label.lower()} at the 3D cursor")
            for key, spec in core.MARKER_SPECS.items()
        ),
    )

    def execute(self, context):
        spec = core.MARKER_SPECS[self.marker_kind]
        try:
            _initialize_scene(context.scene)
            collection, _ = _ensure_collection_path(
                context.scene,
                spec.collection_path,
            )
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        name = core.next_numbered_name(spec.label, set(bpy.data.objects.keys()))

        marker = bpy.data.objects.new(name, None)
        marker.empty_display_type = spec.display_type
        marker.empty_display_size = spec.size
        marker.location = context.scene.cursor.location
        marker.color = spec.color
        marker.show_in_front = True
        collection.objects.link(marker)

        active = context.active_object
        lineage_id = (
            str(active["cmk_lineage_id"])
            if active and "cmk_lineage_id" in active
            else _new_id("lineage")
        )
        identity = core.ensure_source_identity(
            {},
            construction_hint=name,
            lineage_id=lineage_id,
            id_factory=_new_id,
        )
        identity["cmk_role"] = spec.role
        _write_properties(marker, identity)

        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            marker.select_set(True)
            context.view_layer.objects.active = marker

        self.report({"INFO"}, f"Added {name} at the 3D cursor")
        return {"FINISHED"}


_MUSCLE_DYNAMIC_ROLES = {
    core.MUSCLE_COMPONENT_ROLES["rig"],
    core.MUSCLE_COMPONENT_ROLES["origin"],
    core.MUSCLE_COMPONENT_ROLES["belly"],
    core.MUSCLE_COMPONENT_ROLES["insertion"],
    core.MUSCLE_COMPONENT_ROLES["wrap"],
}
_MUSCLE_UPDATE_GUARD = False
_MUSCLE_PENDING_UPDATES: set[str] = set()
_ADDON_KEYMAPS: list[tuple[object, object]] = []
_PATCH_ORIGIN_ROLE = "painted_attachment_origin"
_PATCH_INSERTION_ROLE = "painted_attachment_insertion"
_PATCH_MARKER_ROLES = {_PATCH_ORIGIN_ROLE, _PATCH_INSERTION_ROLE}
_MUSCLE_SETTING_DEFAULTS = {
    "cmk_origin_tendon_fraction": 0.18,
    "cmk_insertion_tendon_fraction": 0.18,
    "cmk_longitudinal_sections": 12,
    "cmk_profile_sides": 12,
    "cmk_patch_thickness": 0.08,
    "cmk_patch_belly_scale": 1.15,
    "cmk_patch_bulge": 0.0,
}
_MUSCLE_CONTROL_ROLES = {
    core.MUSCLE_COMPONENT_ROLES["rig"],
    core.MUSCLE_COMPONENT_ROLES["path"],
    core.MUSCLE_COMPONENT_ROLES["origin"],
    core.MUSCLE_COMPONENT_ROLES["belly"],
    core.MUSCLE_COMPONENT_ROLES["insertion"],
    core.MUSCLE_COMPONENT_ROLES["wrap"],
    *_PATCH_MARKER_ROLES,
}
_MUSCLE_HANDLE_KEYS = ("origin", "belly", "insertion")
_MUSCLE_HANDLE_ROLES = {
    core.MUSCLE_COMPONENT_ROLES[key]
    for key in _MUSCLE_HANDLE_KEYS
}
_MUSCLE_NON_AUTHORING_CONTROL_ROLES = {
    core.MUSCLE_COMPONENT_ROLES["rig"],
    core.MUSCLE_COMPONENT_ROLES["path"],
}
_MUSCLE_REQUIRED_COMPONENT_KEYS = (
    "surface",
    "path",
    "origin",
    "belly",
    "insertion",
)
_MUSCLE_RECOVERY_QUARANTINE = "Recovery Quarantine"


def _muscle_component_names(label: str) -> dict[str, str]:
    return core.muscle_component_names(label)


def _muscle_rig_for_object(obj: bpy.types.Object | None) -> bpy.types.Object | None:
    current = obj
    while current is not None:
        if current.get("cmk_role") == core.MUSCLE_COMPONENT_ROLES["rig"]:
            return current
        current = current.parent
    return None


def _rig_component(rig: bpy.types.Object, key: str) -> bpy.types.Object:
    property_name = f"cmk_{key}_name"
    expected_role = core.MUSCLE_COMPONENT_ROLES[key]
    lineage_id = str(rig.get("cmk_lineage_id", ""))

    def matches(component: bpy.types.Object | None) -> bool:
        return bool(
            component is not None
            and component.parent is rig
            and component.get("cmk_role") == expected_role
            and str(component.get("cmk_lineage_id", "")) == lineage_id
        )

    component = bpy.data.objects.get(str(rig.get(property_name, "")))
    if not matches(component):
        candidates = [
            component
            for component in rig.children
            if component.get("cmk_role") == expected_role
            and str(component.get("cmk_lineage_id", "")) == lineage_id
        ]
        if len(candidates) != 1:
            raise ValueError(
                f"muscle rig requires exactly one {key} component; "
                f"found {len(candidates)}",
            )
        component = candidates[0]
    if rig.get(property_name) != component.name:
        rig[property_name] = component.name
    return component


def _muscle_component_candidates(
    rig: bpy.types.Object,
    key: str,
) -> tuple[bpy.types.Object, ...]:
    expected_role = core.MUSCLE_COMPONENT_ROLES[key]
    lineage_id = str(rig.get("cmk_lineage_id", ""))
    referenced = bpy.data.objects.get(str(rig.get(f"cmk_{key}_name", "")))
    candidates = {
        obj.name: obj
        for obj in bpy.data.objects
        if obj.get("cmk_role") == expected_role
        and str(obj.get("cmk_lineage_id", "")) == lineage_id
        and (
            obj is referenced
            or obj.parent is rig
            or str(obj.get("cmk_muscle_rig_name", "")) == rig.name
        )
    }
    return tuple(candidates[name] for name in sorted(candidates))


def _stamp_muscle_component(
    obj: bpy.types.Object,
    *,
    role: str,
    lineage_id: str,
    rig_name: str,
) -> None:
    identity = core.ensure_source_identity(
        {},
        construction_hint=obj.name,
        lineage_id=lineage_id,
        id_factory=_new_id,
    )
    identity.update(
        {
            "cmk_role": role,
            "cmk_muscle_rig_name": rig_name,
            "cmk_completeness": "wip_procedural",
        },
    )
    _write_properties(obj, identity)


def _handle_local_data(
    rig: bpy.types.Object,
    handle: bpy.types.Object,
) -> tuple[tuple[float, float, float], float, float, tuple[float, float, float]]:
    local_matrix = rig.matrix_world.inverted_safe() @ handle.matrix_world
    position = local_matrix.translation
    scale = local_matrix.to_scale()
    authored_axis = local_matrix.to_3x3() @ Vector((1.0, 0.0, 0.0))
    if authored_axis.length_squared <= 1.0e-12:
        raise ValueError(f"{handle.name} has a collapsed profile orientation")
    authored_axis.normalize()
    return (
        (float(position.x), float(position.y), float(position.z)),
        max(abs(float(scale.x)), 1.0e-4),
        max(abs(float(scale.y)), 1.0e-4),
        (
            float(authored_axis.x),
            float(authored_axis.y),
            float(authored_axis.z),
        ),
    )


def _barycentric_weights(point: Vector, a: Vector, b: Vector, c: Vector):
    edge_ab = b - a
    edge_ac = c - a
    offset = point - a
    dot_ab_ab = edge_ab.dot(edge_ab)
    dot_ab_ac = edge_ab.dot(edge_ac)
    dot_ac_ac = edge_ac.dot(edge_ac)
    dot_offset_ab = offset.dot(edge_ab)
    dot_offset_ac = offset.dot(edge_ac)
    denominator = dot_ab_ab * dot_ac_ac - dot_ab_ac * dot_ab_ac
    if abs(denominator) <= 1.0e-12:
        return None
    second = (dot_ac_ac * dot_offset_ab - dot_ab_ac * dot_offset_ac) / denominator
    third = (dot_ab_ab * dot_offset_ac - dot_ab_ac * dot_offset_ab) / denominator
    return (1.0 - second - third, second, third)


def _triangle_binding(
    source: bpy.types.Object,
    face_index: int,
    local_position: Vector,
) -> tuple[tuple[int, int, int], tuple[float, float, float]] | None:
    if source.type != "MESH" or not 0 <= face_index < len(source.data.polygons):
        return None
    source.data.calc_loop_triangles()
    candidates = [
        triangle
        for triangle in source.data.loop_triangles
        if triangle.polygon_index == face_index
    ]
    best = None
    best_penalty = float("inf")
    for triangle in candidates:
        indices = tuple(int(index) for index in triangle.vertices)
        weights = _barycentric_weights(
            local_position,
            *(source.data.vertices[index].co for index in indices),
        )
        if weights is None:
            continue
        penalty = sum(max(-weight, 0.0) for weight in weights)
        if penalty < best_penalty:
            best = (indices, tuple(float(weight) for weight in weights))
            best_penalty = penalty
    return best


def _attachment_sample_from_hit(
    hit_object: bpy.types.Object,
    location: Vector,
    normal: Vector,
    face_index: int,
    radius: float,
) -> dict[str, object]:
    if hit_object.type != "MESH":
        raise ValueError("painted attachments require a mesh surface")
    local_position = hit_object.matrix_world.inverted_safe() @ location
    local_normal = hit_object.matrix_world.to_3x3().transposed() @ normal
    if local_normal.length_squared <= 1.0e-12:
        raise ValueError("painted attachment hit has a collapsed local normal")
    local_normal.normalize()
    binding = _triangle_binding(hit_object, face_index, local_position)
    triangle_vertices, barycentric = binding or ((), ())
    return {
        "source_object": hit_object.name,
        "source_instance_id": str(hit_object.get("cmk_instance_id", "")),
        "source_mesh_name": hit_object.data.name,
        "source_topology_fingerprint": _mesh_topology_fingerprint(hit_object),
        "source_vertex_count": len(hit_object.data.vertices),
        "source_polygon_count": len(hit_object.data.polygons),
        "face_index": int(face_index),
        "triangle_vertices": list(triangle_vertices),
        "barycentric": list(barycentric),
        "authored_local_position": [float(value) for value in local_position],
        "authored_local_normal": [float(value) for value in local_normal],
        "local_position": [float(value) for value in local_position],
        "local_normal": [float(value) for value in local_normal],
        "world_position": [float(value) for value in location],
        "world_normal": [float(value) for value in normal.normalized()],
        "radius": float(radius),
        "transfer_state": "STABLE",
        "transfer_reasons": [],
        "transfer_method": "painted_hit",
    }


def _mesh_topology_fingerprint(source: bpy.types.Object) -> str:
    return core.topology_fingerprint(
        vertex_count=len(source.data.vertices),
        faces=tuple(tuple(polygon.vertices) for polygon in source.data.polygons),
    )


def _attachment_samples_from_rig(
    rig: bpy.types.Object,
    field: str,
) -> list[dict[str, object]]:
    property_name = f"cmk_{field}_samples_json"
    try:
        samples = json.loads(str(rig.get(property_name, "[]")))
    except json.JSONDecodeError as error:
        raise ValueError(f"{field} attachment evidence is not valid JSON") from error
    if not isinstance(samples, list) or any(not isinstance(item, dict) for item in samples):
        raise ValueError(f"{field} attachment evidence must be a list of samples")
    return samples


def _write_attachment_samples(
    rig: bpy.types.Object,
    field: str,
    samples: list[dict[str, object]],
) -> None:
    rig[f"cmk_{field}_samples_json"] = json.dumps(
        samples,
        sort_keys=True,
        separators=(",", ":"),
    )


def _attachment_evidence_snapshot(rig: bpy.types.Object) -> dict[str, str | None]:
    property_names = (
        "cmk_origin_samples_json",
        "cmk_insertion_samples_json",
    )
    return {
        property_name: str(rig[property_name]) if property_name in rig else None
        for property_name in property_names
    }


def _restore_attachment_evidence(
    rig: bpy.types.Object,
    snapshot: dict[str, str | None],
) -> None:
    for property_name, value in snapshot.items():
        if value is None:
            if property_name in rig:
                del rig[property_name]
        else:
            rig[property_name] = value


def _attachment_source(sample: dict[str, object]) -> bpy.types.Object | None:
    instance_id = str(sample.get("source_instance_id", ""))
    if instance_id:
        matches = [
            obj
            for obj in bpy.data.objects
            if str(obj.get("cmk_instance_id", "")) == instance_id
        ]
        if len(matches) == 1:
            return matches[0]
    return bpy.data.objects.get(str(sample.get("source_object", "")))


def _source_reference_scale(source: bpy.types.Object) -> float:
    corners = tuple(Vector(corner) for corner in source.bound_box)
    if not corners:
        return 1.0
    minimum = Vector(tuple(min(corner[axis] for corner in corners) for axis in range(3)))
    maximum = Vector(tuple(max(corner[axis] for corner in corners) for axis in range(3)))
    return max((maximum - minimum).length, 1.0e-4)


def _transfer_attachment_samples(
    samples: list[dict[str, object]],
) -> tuple[list[dict[str, object]], tuple[dict[str, object], ...]]:
    transferred: list[dict[str, object]] = []
    receipts: list[dict[str, object]] = []
    for original in samples:
        sample = dict(original)
        source = _attachment_source(sample)
        prior_state = str(sample.get("transfer_state", "STABLE"))
        if source is None or source.type != "MESH":
            sample["transfer_state"] = "UNCERTAIN"
            sample["transfer_reasons"] = ["source_missing"]
            sample["transfer_method"] = "source_missing"
            receipts.append(
                {
                    "requested_source": str(sample.get("source_object", "")),
                    "effective_source": "",
                    "status": "UNCERTAIN",
                    "method": "source_missing",
                }
            )
            transferred.append(sample)
            continue

        local_position = Vector(sample.get("authored_local_position", (0.0, 0.0, 0.0)))
        local_normal = Vector(sample.get("authored_local_normal", (0.0, 0.0, 1.0)))
        triangle = tuple(int(index) for index in sample.get("triangle_vertices", ()))
        weights = tuple(float(value) for value in sample.get("barycentric", ()))
        face_index = int(sample.get("face_index", -1))
        face_matches = (
            0 <= face_index < len(source.data.polygons)
            and len(triangle) == 3
            and set(triangle).issubset(set(source.data.polygons[face_index].vertices))
        )
        topology_matches = (
            str(sample.get("source_mesh_name", "")) == source.data.name
            and str(sample.get("source_topology_fingerprint", ""))
            == _mesh_topology_fingerprint(source)
            and int(sample.get("source_vertex_count", -1)) == len(source.data.vertices)
            and int(sample.get("source_polygon_count", -1)) == len(source.data.polygons)
            and len(triangle) == 3
            and len(weights) == 3
            and all(0 <= index < len(source.data.vertices) for index in triangle)
            and face_matches
        )
        method = "topology_binding" if topology_matches else "nearest_surface_projection"
        if topology_matches:
            candidate = sum(
                (source.data.vertices[index].co * weight for index, weight in zip(triangle, weights, strict=True)),
                Vector(),
            )
            if 0 <= face_index < len(source.data.polygons):
                candidate_normal = source.data.polygons[face_index].normal.copy()
            else:
                candidate_normal = local_normal.copy()
            assessment = core.AttachmentTransferAssessment(
                status=prior_state if prior_state == "UNCERTAIN" else "STABLE",
                distance_ratio=0.0,
                normal_alignment=1.0,
                reasons=tuple(str(value) for value in sample.get("transfer_reasons", ())),
            )
        else:
            success, candidate, candidate_normal, face_index = source.closest_point_on_mesh(
                local_position
            )
            if not success:
                sample["transfer_state"] = "UNCERTAIN"
                sample["transfer_reasons"] = ["projection_failed"]
                sample["transfer_method"] = "projection_failed"
                receipts.append(
                    {
                        "requested_source": str(sample.get("source_object", "")),
                        "effective_source": source.name,
                        "status": "UNCERTAIN",
                        "method": "projection_failed",
                    }
                )
                transferred.append(sample)
                continue
            assessment = core.assess_attachment_transfer(
                original_position=tuple(local_position),
                original_normal=tuple(local_normal),
                candidate_position=tuple(candidate),
                candidate_normal=tuple(candidate_normal),
                reference_scale=_source_reference_scale(source),
            )
            if prior_state == "UNCERTAIN":
                assessment = core.AttachmentTransferAssessment(
                    status="UNCERTAIN",
                    distance_ratio=assessment.distance_ratio,
                    normal_alignment=assessment.normal_alignment,
                    reasons=tuple(str(value) for value in sample.get("transfer_reasons", ()))
                    or assessment.reasons,
                )
            binding = _triangle_binding(source, int(face_index), candidate)
            if binding is not None:
                sample["triangle_vertices"] = list(binding[0])
                sample["barycentric"] = list(binding[1])
                sample["face_index"] = int(face_index)
                sample["source_vertex_count"] = len(source.data.vertices)
                sample["source_polygon_count"] = len(source.data.polygons)

        if candidate_normal.length_squared <= 1.0e-12:
            candidate_normal = local_normal.copy()
        candidate_normal.normalize()
        world_position = source.matrix_world @ candidate
        world_normal = source.matrix_world.to_3x3().inverted_safe().transposed() @ candidate_normal
        world_normal.normalize()
        sample.update(
            {
                "source_object": source.name,
                "source_instance_id": str(source.get("cmk_instance_id", "")),
                "source_mesh_name": source.data.name,
                "source_topology_fingerprint": _mesh_topology_fingerprint(source),
                "local_position": [float(value) for value in candidate],
                "local_normal": [float(value) for value in candidate_normal],
                "world_position": [float(value) for value in world_position],
                "world_normal": [float(value) for value in world_normal],
                "transfer_state": assessment.status,
                "transfer_reasons": list(assessment.reasons),
                "transfer_method": method,
            }
        )
        receipts.append(
            {
                "requested_source": str(original.get("source_object", "")),
                "effective_source": source.name,
                "status": assessment.status,
                "method": method,
                "distance_ratio": assessment.distance_ratio,
                "normal_alignment": assessment.normal_alignment,
            }
        )
        transferred.append(sample)
    return transferred, tuple(receipts)


def _core_attachment_samples(
    rig: bpy.types.Object,
    samples: list[dict[str, object]],
) -> tuple[core.AttachmentSample, ...]:
    rig_inverse = rig.matrix_world.inverted_safe()
    rig_normal_inverse = rig.matrix_world.to_3x3().transposed()
    rig_scale = max((rig.matrix_world.to_scale()), default=1.0)
    result: list[core.AttachmentSample] = []
    for sample in samples:
        source = _attachment_source(sample)
        if source is not None and source.type == "MESH":
            local_position = Vector(sample.get("local_position", (0.0, 0.0, 0.0)))
            local_normal = Vector(sample.get("local_normal", (0.0, 0.0, 1.0)))
            world_position = source.matrix_world @ local_position
            world_normal = source.matrix_world.to_3x3().inverted_safe().transposed() @ local_normal
        else:
            world_position = Vector(sample.get("world_position", (0.0, 0.0, 0.0)))
            world_normal = Vector(sample.get("world_normal", (0.0, 0.0, 1.0)))
        if world_normal.length_squared <= 1.0e-12:
            raise ValueError("painted attachment contains a collapsed normal")
        world_normal.normalize()
        rig_normal = rig_normal_inverse @ world_normal
        rig_normal.normalize()
        result.append(
            core.AttachmentSample(
                position=tuple(float(value) for value in (rig_inverse @ world_position)),
                normal=tuple(float(value) for value in rig_normal),
                radius=max(float(sample.get("radius", 0.01)) / max(rig_scale, 1.0e-6), 1.0e-4),
                source_object=str(sample.get("source_object", "")),
                source_instance_id=str(sample.get("source_instance_id", "")),
                face_index=int(sample.get("face_index", -1)),
                source_vertex_count=int(sample.get("source_vertex_count", 0)),
                source_polygon_count=int(sample.get("source_polygon_count", 0)),
            )
        )
    return tuple(result)


def _ensure_paint_material(name: str, color) -> bpy.types.Material:
    material = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    material.diffuse_color = color
    material.metallic = 0.0
    material.roughness = 0.48
    return material


def _replace_attachment_marker(
    rig: bpy.types.Object,
    field: str,
    samples: list[dict[str, object]],
) -> bpy.types.Object:
    role = _PATCH_ORIGIN_ROLE if field == "origin" else _PATCH_INSERTION_ROLE
    marker = next((child for child in rig.children if child.get("cmk_role") == role), None)
    if marker is None:
        mesh = bpy.data.meshes.new(f"{rig.name} | {field.title()} Paint Mesh")
        marker = bpy.data.objects.new(f"{rig.name} | {field.title()} Paint", mesh)
        _muscle_collection(bpy.context).objects.link(marker)
        marker.parent = rig
        marker.show_in_front = True
        marker.hide_render = True
        marker.hide_select = True
        _stamp_muscle_component(
            marker,
            role=role,
            lineage_id=str(rig["cmk_lineage_id"]),
            rig_name=rig.name,
        )
    core_samples = _core_attachment_samples(rig, samples)
    vertices: list[tuple[float, float, float]] = []
    faces: list[tuple[int, ...]] = []
    uncertain: list[bool] = []
    for sample, authored in zip(core_samples, samples, strict=True):
        normal = Vector(sample.normal).normalized()
        first = normal.orthogonal().normalized() * max(sample.radius * 0.32, 0.002)
        second = normal.cross(first).normalized() * first.length
        center = Vector(sample.position)
        start = len(vertices)
        vertices.extend(
            tuple(float(value) for value in point)
            for point in (
                center + first,
                center + second,
                center - first,
                center - second,
            )
        )
        faces.append((start, start + 1, start + 2, start + 3))
        uncertain.append(str(authored.get("transfer_state", "STABLE")) == "UNCERTAIN")

    previous = marker.data
    replacement = bpy.data.meshes.new(f"{previous.name}.replacement")
    replacement.from_pydata(vertices, (), faces)
    stable_color = (0.88, 0.12, 0.42, 1.0) if field == "origin" else (0.05, 0.72, 0.82, 1.0)
    replacement.materials.append(_ensure_paint_material(f"CMK | {field.title()} Paint", stable_color))
    replacement.materials.append(_ensure_paint_material("CMK | Uncertain Paint", (1.0, 0.58, 0.03, 1.0)))
    for polygon, is_uncertain in zip(replacement.polygons, uncertain, strict=True):
        polygon.material_index = int(is_uncertain)
    replacement.update()
    previous_name = previous.name
    marker.data = replacement
    if previous.users == 0:
        bpy.data.meshes.remove(previous)
        replacement.name = previous_name
    marker.hide_select = True
    return marker


def _update_generated_patch_handles(
    rig: bpy.types.Object,
    result: core.MuscleMesh,
    *,
    rings: int,
    sides: int,
) -> None:
    profiles = core.recover_muscle_profiles(result.vertices, rings=rings, sides=sides)
    for key, profile in zip(_MUSCLE_HANDLE_KEYS, profiles, strict=True):
        handle = _rig_component(rig, key)
        normal = Vector(profile.normal).normalized()
        binormal = Vector(profile.binormal).normalized()
        tangent = normal.cross(binormal).normalized()
        handle.location = profile.position
        handle.rotation_mode = "QUATERNION"
        handle.rotation_quaternion = Matrix((normal, binormal, tangent)).transposed().to_quaternion()
        handle.scale = (profile.width, profile.depth, max(profile.width, profile.depth))
        handle.hide_select = True
        handle.show_name = False


_PATCH_UPDATE_PROPERTIES = (
    "cmk_origin_samples_json",
    "cmk_insertion_samples_json",
    "cmk_patch_uncertain_count",
    "cmk_patch_status",
    "cmk_patch_source_names",
    "cmk_patch_transfer_receipt",
    "cmk_update_error",
)


def _remove_orphan_component_data(data) -> None:
    if data is None or data.users:
        return
    if isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
    elif isinstance(data, bpy.types.Curve):
        bpy.data.curves.remove(data)


def _snapshot_patch_update(rig: bpy.types.Object) -> dict[str, object]:
    tracked = [
        _rig_component(rig, key)
        for key in ("surface", "path", *_MUSCLE_HANDLE_KEYS)
    ]
    tracked.extend(child for child in rig.children if child.get("cmk_role") in _PATCH_MARKER_ROLES)
    component_states: list[dict[str, object]] = []
    try:
        for component in tracked:
            data_backup = component.data.copy() if component.data is not None else None
            component_states.append(
                {
                    "component": component,
                    "data_backup": data_backup,
                    "parent": component.parent,
                    "matrix_parent_inverse": component.matrix_parent_inverse.copy(),
                    "matrix_basis": component.matrix_basis.copy(),
                    "hide_select": component.hide_select,
                    "hide_render": component.hide_render,
                    "show_in_front": component.show_in_front,
                    "show_name": component.show_name,
                }
            )
    except Exception:
        for state in component_states:
            _remove_orphan_component_data(state["data_backup"])
        raise
    return {
        "properties": {
            name: (name in rig, rig.get(name))
            for name in _PATCH_UPDATE_PROPERTIES
        },
        "component_states": component_states,
        "marker_names": {
            child.name
            for child in rig.children
            if child.get("cmk_role") in _PATCH_MARKER_ROLES
        },
    }


def _discard_patch_update_snapshot(snapshot: dict[str, object]) -> None:
    for state in snapshot["component_states"]:
        backup = state.get("data_backup")
        if backup is not None:
            _remove_orphan_component_data(backup)
            state["data_backup"] = None


def _restore_patch_update(rig: bpy.types.Object, snapshot: dict[str, object]) -> None:
    marker_names = snapshot["marker_names"]
    for child in tuple(rig.children):
        if child.get("cmk_role") not in _PATCH_MARKER_ROLES or child.name in marker_names:
            continue
        data = child.data
        bpy.data.objects.remove(child, do_unlink=True)
        _remove_orphan_component_data(data)

    for state in snapshot["component_states"]:
        component = state["component"]
        if component.name not in bpy.data.objects:
            continue
        backup = state["data_backup"]
        if backup is not None:
            current = component.data
            component.data = backup
            state["data_backup"] = None
            _remove_orphan_component_data(current)
        component.parent = state["parent"]
        component.matrix_parent_inverse = state["matrix_parent_inverse"]
        component.matrix_basis = state["matrix_basis"]
        component.hide_select = state["hide_select"]
        component.hide_render = state["hide_render"]
        component.show_in_front = state["show_in_front"]
        component.show_name = state["show_name"]

    for property_name, (present, value) in snapshot["properties"].items():
        if present:
            rig[property_name] = value
        elif property_name in rig:
            del rig[property_name]
    _discard_patch_update_snapshot(snapshot)


def _update_patch_muscle_rig(rig: bpy.types.Object) -> None:
    snapshot = _snapshot_patch_update(rig)
    try:
        _update_patch_muscle_rig_unchecked(rig)
    except Exception as error:
        try:
            _restore_patch_update(rig, snapshot)
        except Exception as rollback_error:
            raise RuntimeError(
                f"patch refresh failed: {error}; rollback failed: {rollback_error}"
            ) from rollback_error
        raise
    else:
        _discard_patch_update_snapshot(snapshot)


def _update_patch_muscle_rig_unchecked(rig: bpy.types.Object) -> None:
    transfer_receipt: dict[str, object] = {"requested_route": "painted_attachments"}
    fields: dict[str, list[dict[str, object]]] = {}
    all_receipts: dict[str, object] = {}
    for field in ("origin", "insertion"):
        transferred, receipts = _transfer_attachment_samples(
            _attachment_samples_from_rig(rig, field)
        )
        if not transferred:
            raise ValueError(f"painted muscle requires at least one {field} sample")
        _write_attachment_samples(rig, field, transferred)
        fields[field] = transferred
        all_receipts[field] = receipts

    rings = max(int(rig.cmk_longitudinal_sections), 2) * 2 + 1
    sides = max(int(rig.cmk_profile_sides), 4)
    result = core.build_patch_muscle_mesh(
        core.PatchMuscleBuildSpec(
            origin_samples=_core_attachment_samples(rig, fields["origin"]),
            insertion_samples=_core_attachment_samples(rig, fields["insertion"]),
            thickness=float(rig.cmk_patch_thickness),
            belly_scale=float(rig.cmk_patch_belly_scale),
            bulge=float(rig.cmk_patch_bulge),
            origin_tendon_fraction=float(rig.cmk_origin_tendon_fraction),
            insertion_tendon_fraction=float(rig.cmk_insertion_tendon_fraction),
            rings=rings,
            sides=sides,
        )
    )
    surface = _rig_component(rig, "surface")
    path = _rig_component(rig, "path")
    _reset_generated_component_transform(rig, surface)
    _reset_generated_component_transform(rig, path)
    _replace_muscle_mesh(surface, result)
    _replace_muscle_path(path, result.ring_centers)
    _update_generated_patch_handles(rig, result, rings=rings, sides=sides)
    _replace_attachment_marker(rig, "origin", fields["origin"])
    _replace_attachment_marker(rig, "insertion", fields["insertion"])

    all_samples = fields["origin"] + fields["insertion"]
    uncertain_count = sum(
        str(sample.get("transfer_state", "STABLE")) == "UNCERTAIN"
        for sample in all_samples
    )
    rig["cmk_patch_uncertain_count"] = uncertain_count
    rig["cmk_patch_status"] = "UNCERTAIN" if uncertain_count else "STABLE"
    rig["cmk_patch_source_names"] = json.dumps(
        sorted({str(sample.get("source_object", "")) for sample in all_samples})
    )
    transfer_receipt.update(
        {
            "effective_route": "topology_binding_or_guarded_projection",
            "origin": all_receipts["origin"],
            "insertion": all_receipts["insertion"],
            "uncertain_count": uncertain_count,
        }
    )
    rig["cmk_patch_transfer_receipt"] = json.dumps(transfer_receipt, sort_keys=True)
    if "cmk_update_error" in rig:
        del rig["cmk_update_error"]


def _muscle_build_spec(rig: bpy.types.Object) -> core.MuscleBuildSpec:
    origin = _handle_local_data(rig, _rig_component(rig, "origin"))
    belly = _handle_local_data(rig, _rig_component(rig, "belly"))
    insertion = _handle_local_data(rig, _rig_component(rig, "insertion"))
    longitudinal_sections = max(
        int(
            getattr(
                rig,
                "cmk_longitudinal_sections",
                rig.get("cmk_longitudinal_sections", 12),
            )
        ),
        2,
    )
    return core.MuscleBuildSpec(
        origin=origin[0],
        belly=belly[0],
        insertion=insertion[0],
        origin_width=origin[1],
        origin_depth=origin[2],
        belly_width=belly[1],
        belly_depth=belly[2],
        insertion_width=insertion[1],
        insertion_depth=insertion[2],
        origin_up=origin[3],
        belly_up=belly[3],
        insertion_up=insertion[3],
        origin_tendon_fraction=float(
            getattr(
                rig,
                "cmk_origin_tendon_fraction",
                rig.get("cmk_origin_tendon_fraction", 0.18),
            )
        ),
        insertion_tendon_fraction=float(
            getattr(
                rig,
                "cmk_insertion_tendon_fraction",
                rig.get("cmk_insertion_tendon_fraction", 0.18),
            )
        ),
        rings=longitudinal_sections * 2 + 1,
        sides=max(
            int(
                getattr(
                    rig,
                    "cmk_profile_sides",
                    rig.get("cmk_profile_sides", 12),
                )
            ),
            4,
        ),
    )


def _replace_muscle_mesh(
    surface: bpy.types.Object,
    result: core.MuscleMesh,
) -> None:
    material_by_name = {spec.name: spec for spec in core.MATERIAL_SPECS}
    for name in ("CMK | Muscle", "CMK | Tendon"):
        _ensure_material(material_by_name[name])
    muscle_material = bpy.data.materials["CMK | Muscle"]
    tendon_material = bpy.data.materials["CMK | Tendon"]

    previous = surface.data
    replacement = bpy.data.meshes.new(f"{previous.name}.replacement")
    try:
        replacement.from_pydata(result.vertices, (), result.faces)
        replacement.validate(clean_customdata=False)
        replacement.materials.append(muscle_material)
        replacement.materials.append(tendon_material)
        for polygon, region in zip(
            replacement.polygons,
            result.face_regions,
            strict=True,
        ):
            polygon.material_index = int(region != "muscle_belly")
            polygon.use_smooth = region not in {
                "attachment_origin",
                "attachment_insertion",
            }
        replacement.update()
    except Exception:
        bpy.data.meshes.remove(replacement)
        raise

    previous_name = previous.name
    surface.data = replacement
    if previous.users == 0:
        bpy.data.meshes.remove(previous)
        replacement.name = previous_name


def _replace_muscle_path(
    path: bpy.types.Object,
    centers: tuple[tuple[float, float, float], ...],
) -> None:
    previous = path.data
    replacement = previous.copy()
    try:
        replacement.splines.clear()
        spline = replacement.splines.new("POLY")
        spline.points.add(len(centers) - 1)
        for point, center in zip(spline.points, centers, strict=True):
            point.co = (*center, 1.0)
        replacement.update_tag()
    except Exception:
        bpy.data.curves.remove(replacement)
        raise

    previous_name = previous.name
    path.data = replacement
    if previous.users == 0:
        bpy.data.curves.remove(previous)
        replacement.name = previous_name


def _reset_generated_component_transform(
    rig: bpy.types.Object,
    component: bpy.types.Object,
) -> None:
    component.parent = rig
    component.matrix_parent_inverse = Matrix.Identity(4)
    component.matrix_basis = Matrix.Identity(4)


def _update_muscle_rig(rig: bpy.types.Object) -> None:
    if str(rig.get("cmk_muscle_kind", "AXIAL")) == "PATCH":
        _update_patch_muscle_rig(rig)
        return
    result = core.build_muscle_mesh(_muscle_build_spec(rig))
    surface = _rig_component(rig, "surface")
    path = _rig_component(rig, "path")
    _reset_generated_component_transform(rig, surface)
    _reset_generated_component_transform(rig, path)
    _replace_muscle_mesh(surface, result)
    _replace_muscle_path(path, result.ring_centers)
    if "cmk_update_error" in rig:
        del rig["cmk_update_error"]


def _muscle_setting_update(rig: bpy.types.Object, context) -> None:
    global _MUSCLE_UPDATE_GUARD
    if (
        _MUSCLE_UPDATE_GUARD
        or rig.get("cmk_role") != core.MUSCLE_COMPONENT_ROLES["rig"]
    ):
        return

    _MUSCLE_UPDATE_GUARD = True
    try:
        _update_muscle_rig(rig)
    except (KeyError, RuntimeError, TypeError, ValueError) as error:
        rig["cmk_update_error"] = str(error)
    finally:
        _MUSCLE_UPDATE_GUARD = False


def _migrate_muscle_settings() -> int:
    global _MUSCLE_UPDATE_GUARD
    migrated = 0
    _MUSCLE_UPDATE_GUARD = True
    try:
        for rig in _muscle_rigs():
            errors: list[str] = []
            for key in _MUSCLE_SETTING_DEFAULTS:
                if key not in rig:
                    continue
                value = rig[key]
                del rig[key]
                try:
                    setattr(rig, key, value)
                except Exception as error:
                    if key in rig:
                        del rig[key]
                    rig[key] = value
                    errors.append(f"{key}: {error}")
                    continue
                migrated += 1
            if errors:
                rig["cmk_migration_error"] = "; ".join(errors)
            elif "cmk_migration_error" in rig:
                del rig["cmk_migration_error"]
    finally:
        _MUSCLE_UPDATE_GUARD = False
    return migrated


def _deferred_migrate_muscle_settings() -> None:
    try:
        _migrate_muscle_settings()
    except Exception as error:
        bpy.context.scene["cmk_migration_error"] = str(error)
    else:
        if "cmk_migration_error" in bpy.context.scene:
            del bpy.context.scene["cmk_migration_error"]
    return None


def _muscle_rigs() -> tuple[bpy.types.Object, ...]:
    return tuple(
        obj
        for obj in bpy.data.objects
        if obj.get("cmk_role") == core.MUSCLE_COMPONENT_ROLES["rig"]
    )


def _surface_recovery_profiles(
    rig: bpy.types.Object,
    surface: bpy.types.Object,
) -> tuple[core.RecoveredMuscleProfile, ...]:
    if surface.type != "MESH":
        raise ValueError(f"{surface.name} is not a mesh surface")
    rings = max(
        int(
            getattr(
                rig,
                "cmk_longitudinal_sections",
                rig.get("cmk_longitudinal_sections", 12),
            )
        ),
        2,
    ) * 2 + 1
    sides = max(
        int(
            getattr(
                rig,
                "cmk_profile_sides",
                rig.get("cmk_profile_sides", 12),
            )
        ),
        4,
    )
    vertices = tuple(
        tuple(float(value) for value in vertex.co)
        for vertex in surface.data.vertices
    )
    return core.recover_muscle_profiles(vertices, rings=rings, sides=sides)


def _audit_muscle_rig(rig: bpy.types.Object) -> dict[str, object]:
    candidates = {
        key: _muscle_component_candidates(rig, key)
        for key in _MUSCLE_REQUIRED_COMPONENT_KEYS
    }
    present = {key for key, values in candidates.items() if len(values) == 1}
    conflicting = {key for key, values in candidates.items() if len(values) > 1}
    profiles: tuple[core.RecoveredMuscleProfile, ...] = ()
    surface_profile_error = ""
    if len(candidates["surface"]) == 1:
        try:
            profiles = _surface_recovery_profiles(rig, candidates["surface"][0])
        except (RuntimeError, TypeError, ValueError) as error:
            surface_profile_error = str(error)

    status = core.classify_muscle_recovery(
        present_components=present,
        conflicting_components=conflicting,
        surface_profile_valid=bool(profiles),
    )
    return {
        "status": status,
        "present": tuple(sorted(present)),
        "missing": tuple(sorted(set(_MUSCLE_REQUIRED_COMPONENT_KEYS) - present)),
        "conflicting": tuple(sorted(conflicting)),
        "surface_profiles": profiles,
        "surface_profile_error": surface_profile_error,
        "candidates": candidates,
    }


def _record_muscle_audit(rig: bpy.types.Object, audit: dict[str, object]) -> None:
    rig["cmk_recovery_status"] = str(audit["status"])
    rig["cmk_recovery_missing"] = ", ".join(audit["missing"])
    rig["cmk_recovery_conflicting"] = ", ".join(audit["conflicting"])
    rig["cmk_recovery_surface_error"] = str(audit["surface_profile_error"])


def _audit_all_muscles(scene) -> dict[str, object]:
    audits: dict[str, dict[str, object]] = {}
    counts = {status: 0 for status in ("refreshable", "reconstructible", "remake_required")}
    linked_component_names: set[str] = set()
    for rig in _muscle_rigs():
        audit = _audit_muscle_rig(rig)
        _record_muscle_audit(rig, audit)
        audits[rig.name] = audit
        counts[str(audit["status"])] += 1
        for values in audit["candidates"].values():
            linked_component_names.update(obj.name for obj in values)

    component_roles = {
        core.MUSCLE_COMPONENT_ROLES[key]
        for key in _MUSCLE_REQUIRED_COMPONENT_KEYS
    }
    orphan_components = tuple(
        obj
        for obj in bpy.data.objects
        if obj.get("cmk_role") in component_roles
        and obj.name not in linked_component_names
    )
    summary = {
        **counts,
        "orphan_components": len(orphan_components),
        "total_rigs": len(audits),
    }
    scene["cmk_muscle_audit_summary"] = json.dumps(summary, sort_keys=True)
    scene["cmk_muscle_audit_orphans"] = ", ".join(
        obj.name for obj in orphan_components
    )
    return {
        "audits": audits,
        "summary": summary,
        "orphan_components": orphan_components,
    }


def _muscle_collection(context) -> bpy.types.Collection:
    collection, _ = _ensure_collection_path(
        context.scene,
        (core.ROOT_COLLECTION, "20 Muscle"),
    )
    return collection


def _recovery_component_name(rig: bpy.types.Object, key: str) -> str:
    desired = _muscle_component_names(rig.name)[key]
    return core.next_numbered_name(desired, set(bpy.data.objects.keys()))


def _recover_muscle_handle(
    context,
    rig: bpy.types.Object,
    key: str,
    profile: core.RecoveredMuscleProfile,
) -> bpy.types.Object:
    normal = Vector(profile.normal).normalized()
    binormal = Vector(profile.binormal).normalized()
    tangent = normal.cross(binormal).normalized()
    rotation = Matrix((normal, binormal, tangent)).transposed().to_quaternion()
    handle = _new_muscle_handle(
        _recovery_component_name(rig, key),
        role=core.MUSCLE_COMPONENT_ROLES[key],
        location=Vector(profile.position),
        rotation=rotation,
        dimensions=(profile.width, profile.depth),
        parent=rig,
        collection=_muscle_collection(context),
        lineage_id=str(rig["cmk_lineage_id"]),
        display_type="SPHERE" if key == "belly" else "CIRCLE",
    )
    handle["cmk_recovery_source"] = "generated_surface_profile"
    handle["cmk_recovery_version"] = "0.3.3"
    rig[f"cmk_{key}_name"] = handle.name
    return handle


def _recover_generated_component(
    context,
    rig: bpy.types.Object,
    key: str,
) -> bpy.types.Object:
    name = _recovery_component_name(rig, key)
    if key == "surface":
        data = bpy.data.meshes.new(f"{name} Mesh")
        component = bpy.data.objects.new(name, data)
    elif key == "path":
        data = bpy.data.curves.new(f"{name} Curve", "CURVE")
        data.dimensions = "3D"
        data.resolution_u = 2
        data.bevel_depth = 0.002
        data.bevel_resolution = 2
        data.materials.append(bpy.data.materials["CMK | Segment Axis"])
        component = bpy.data.objects.new(name, data)
        component.show_in_front = True
        component.hide_render = True
        component.hide_select = True
    else:
        raise ValueError(f"cannot regenerate unsupported component {key}")

    _muscle_collection(context).objects.link(component)
    component.parent = rig
    _stamp_muscle_component(
        component,
        role=core.MUSCLE_COMPONENT_ROLES[key],
        lineage_id=str(rig["cmk_lineage_id"]),
        rig_name=rig.name,
    )
    component["cmk_recovery_source"] = "authored_handles"
    component["cmk_recovery_version"] = "0.3.3"
    rig[f"cmk_{key}_name"] = component.name
    return component


def _remove_recovered_component(component: bpy.types.Object) -> None:
    data = component.data
    bpy.data.objects.remove(component, do_unlink=True)
    if data is None or data.users:
        return
    if isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
    elif isinstance(data, bpy.types.Curve):
        bpy.data.curves.remove(data)


def _recover_muscle_rig(
    context,
    rig: bpy.types.Object,
    audit: dict[str, object] | None = None,
) -> tuple[str, ...]:
    audit = audit or _audit_muscle_rig(rig)
    if audit["status"] == "remake_required":
        raise ValueError(f"{rig.name} is underdetermined and requires remake")

    recovered: list[str] = []
    created_components: list[bpy.types.Object] = []
    existing_component_state: list[
        tuple[bpy.types.Object, object, Matrix, bool, object]
    ] = []
    rig_reference_state = {
        f"cmk_{key}_name": (
            f"cmk_{key}_name" in rig,
            rig.get(f"cmk_{key}_name"),
        )
        for key in _MUSCLE_REQUIRED_COMPONENT_KEYS
    }
    candidates = audit["candidates"]
    try:
        for key in _MUSCLE_REQUIRED_COMPONENT_KEYS:
            values = candidates[key]
            if len(values) == 1:
                component = values[0]
                world_matrix = component.matrix_world.copy()
                had_rig_name = "cmk_muscle_rig_name" in component
                existing_component_state.append(
                    (
                        component,
                        component.parent,
                        world_matrix,
                        had_rig_name,
                        component.get("cmk_muscle_rig_name"),
                    )
                )
                component.parent = rig
                if key in _MUSCLE_HANDLE_KEYS:
                    component.matrix_world = world_matrix
                component["cmk_muscle_rig_name"] = rig.name
                rig[f"cmk_{key}_name"] = component.name

        profiles = audit["surface_profiles"]
        profile_by_key = dict(zip(_MUSCLE_HANDLE_KEYS, profiles, strict=False))
        for key in _MUSCLE_HANDLE_KEYS:
            if len(candidates[key]) == 0:
                profile = profile_by_key.get(key)
                if profile is None:
                    raise ValueError(f"{rig.name} cannot recover missing {key} handle")
                component = _recover_muscle_handle(context, rig, key, profile)
                created_components.append(component)
                recovered.append(key)

        for key in ("surface", "path"):
            if len(candidates[key]) == 0:
                component = _recover_generated_component(context, rig, key)
                created_components.append(component)
                recovered.append(key)

        context.view_layer.update()
        _update_muscle_rig(rig)
    except Exception:
        for component in reversed(created_components):
            if component.name in bpy.data.objects:
                _remove_recovered_component(component)
        for component, parent, world_matrix, had_rig_name, rig_name in reversed(
            existing_component_state
        ):
            component.parent = parent
            component.matrix_world = world_matrix
            if had_rig_name:
                component["cmk_muscle_rig_name"] = rig_name
            elif "cmk_muscle_rig_name" in component:
                del component["cmk_muscle_rig_name"]
        for property_name, (existed, value) in rig_reference_state.items():
            if existed:
                rig[property_name] = value
            elif property_name in rig:
                del rig[property_name]
        raise

    rig["cmk_recovery_status"] = "refreshable"
    rig["cmk_recovered_components"] = ", ".join(recovered)
    if "cmk_recovery_error" in rig:
        del rig["cmk_recovery_error"]
    return tuple(recovered)


def _muscle_surfaces_for_display(
    rig: bpy.types.Object,
) -> tuple[bpy.types.Object, ...]:
    expected_role = core.MUSCLE_COMPONENT_ROLES["surface"]
    lineage_id = str(rig.get("cmk_lineage_id", ""))
    referenced = bpy.data.objects.get(str(rig.get("cmk_surface_name", "")))
    candidates = {
        obj.name: obj
        for obj in bpy.data.objects
        if obj.get("cmk_role") == expected_role
        and (
            obj is referenced
            or obj.parent is rig
            or str(obj.get("cmk_muscle_rig_name", "")) == rig.name
            or (
                lineage_id
                and str(obj.get("cmk_lineage_id", "")) == lineage_id
            )
        )
    }
    return tuple(candidates[name] for name in sorted(candidates))


def _set_muscle_display(
    context,
    mode: str,
) -> tuple[int, int, tuple[str, ...]]:
    if mode not in {"FORM", "SELECTED", "ALL"}:
        raise ValueError(f"unknown muscle display mode: {mode}")

    active_rig = _muscle_rig_for_object(context.active_object)
    if mode == "SELECTED" and active_rig is None:
        raise ValueError("select a muscle surface or control first")

    visible_controls = 0
    hidden_controls = 0
    incomplete_rigs: list[str] = []
    for rig in _muscle_rigs():
        is_patch = str(rig.get("cmk_muscle_kind", "AXIAL")) == "PATCH"
        show_controls = mode == "ALL" or (
            mode == "SELECTED" and rig is active_rig
        )
        controls = (rig,) + tuple(
            child
            for child in rig.children
            if child.get("cmk_role") in _MUSCLE_CONTROL_ROLES
        )
        for control in controls:
            role = control.get("cmk_role")
            control.hide_select = role in _MUSCLE_NON_AUTHORING_CONTROL_ROLES
            if is_patch and role in _MUSCLE_HANDLE_ROLES:
                control.hide_select = True
                control.show_name = False
                control.hide_set(True)
                hidden_controls += 1
                continue
            control.show_name = bool(
                mode == "SELECTED"
                and show_controls
                and role in _MUSCLE_HANDLE_ROLES
            )
            control.hide_set(not show_controls)
            visible_controls += int(show_controls)
            hidden_controls += int(not show_controls)
        surfaces = _muscle_surfaces_for_display(rig)
        for surface in surfaces:
            surface.hide_set(False)
        if not surfaces:
            incomplete_rigs.append(rig.name)

    space_data = getattr(context, "space_data", None)
    overlay = getattr(space_data, "overlay", None)
    if overlay is not None:
        overlay.show_relationship_lines = mode == "ALL"
    context.scene["cmk_muscle_display_mode"] = mode
    context.scene["cmk_muscle_display_incomplete_rigs"] = ", ".join(
        incomplete_rigs
    )
    return visible_controls, hidden_controls, tuple(incomplete_rigs)


def _selected_muscle_rigs(context) -> tuple[bpy.types.Object, ...]:
    rigs = {
        rig.name: rig
        for obj in context.selected_objects
        if (rig := _muscle_rig_for_object(obj)) is not None
    }
    active_rig = _muscle_rig_for_object(context.active_object)
    if active_rig is not None:
        rigs[active_rig.name] = active_rig
    return tuple(rigs[name] for name in sorted(rigs))


def _rename_muscle_rigs(
    rigs: tuple[bpy.types.Object, ...],
    stem: str,
) -> tuple[core.MuscleRenamePlan, ...]:
    if not rigs:
        raise ValueError("select at least one muscle surface or control")
    current_labels = tuple(rig.name for rig in rigs)
    plans = core.plan_muscle_renames(
        current_labels,
        stem,
        set(bpy.data.objects.keys()),
    )
    components = {
        rig.name: {
            "rig": rig,
            **{
                key: _rig_component(rig, key)
                for key in ("surface", "path", "origin", "belly", "insertion")
            },
        }
        for rig in rigs
    }
    replacement_by_old = {
        plan.old_label: plan.new_label
        for plan in plans
    }
    references = tuple(
        obj
        for obj in bpy.data.objects
        if str(obj.get("cmk_muscle_rig_name", "")) in replacement_by_old
    )

    for group in components.values():
        for obj in group.values():
            obj.name = _new_id("cmk-rename")

    for plan in plans:
        group = components[plan.old_label]
        names = _muscle_component_names(plan.new_label)
        for key, obj in group.items():
            obj.name = names[key]
        rig = group["rig"]
        for key in ("surface", "path", "origin", "belly", "insertion"):
            rig[f"cmk_{key}_name"] = group[key].name
        for obj in group.values():
            obj["cmk_muscle_rig_name"] = rig.name

    for obj in references:
        old_name = str(obj.get("cmk_muscle_rig_name", ""))
        if old_name in replacement_by_old:
            obj["cmk_muscle_rig_name"] = replacement_by_old[old_name]
    return plans


def _new_muscle_handle(
    name: str,
    *,
    role: str,
    location: Vector,
    rotation,
    dimensions: tuple[float, float],
    parent: bpy.types.Object,
    collection: bpy.types.Collection,
    lineage_id: str,
    display_type: str,
) -> bpy.types.Object:
    handle = bpy.data.objects.new(name, None)
    collection.objects.link(handle)
    handle.parent = parent
    handle.location = location
    handle.rotation_mode = "QUATERNION"
    handle.rotation_quaternion = rotation
    handle.scale = (dimensions[0], dimensions[1], max(dimensions))
    handle.empty_display_type = display_type
    handle.empty_display_size = 1.0
    handle.show_in_front = True
    handle.color = (0.83, 0.15, 0.50, 1.0)
    _stamp_muscle_component(
        handle,
        role=role,
        lineage_id=lineage_id,
        rig_name=parent.name,
    )
    return handle


def _create_muscle_rig(
    context,
    *,
    origin_world: Vector,
    insertion_world: Vector,
    origin_rotation=None,
    insertion_rotation=None,
    origin_source: str = "",
    insertion_source: str = "",
    endpoint_route: str,
    endpoint_strategy: str = "authored_points",
) -> tuple[bpy.types.Object, bpy.types.Object]:
    separation = insertion_world - origin_world
    if separation.length <= 1.0e-6:
        raise ValueError(
            core.muscle_endpoint_failure_message(
                route=endpoint_route,
                strategy=endpoint_strategy,
                stage="rig_preflight",
                origin=tuple(float(value) for value in origin_world),
                insertion=tuple(float(value) for value in insertion_world),
            )
        )

    _initialize_scene(context.scene)
    collection, _ = _ensure_collection_path(
        context.scene,
        (core.ROOT_COLLECTION, "20 Muscle"),
    )
    label = core.next_muscle_label(
        origin_source,
        insertion_source,
        set(bpy.data.objects.keys()),
    )
    names = _muscle_component_names(label)
    lineage_id = _new_id("lineage")
    direction_rotation = separation.normalized().to_track_quat("Z", "Y")
    origin_rotation = origin_rotation or direction_rotation
    insertion_rotation = insertion_rotation or direction_rotation
    length = separation.length
    attachment_dimensions = (max(length * 0.035, 0.02), max(length * 0.025, 0.015))
    belly_dimensions = (max(length * 0.13, 0.06), max(length * 0.085, 0.04))

    created_objects: list[bpy.types.Object] = []
    created_data: list[object] = []
    try:
        rig = bpy.data.objects.new(names["rig"], None)
        created_objects.append(rig)
        collection.objects.link(rig)
        rig.empty_display_type = "PLAIN_AXES"
        rig.empty_display_size = max(length * 0.18, 0.1)
        rig.show_in_front = True
        rig.hide_select = True
        _stamp_muscle_component(
            rig,
            role=core.MUSCLE_COMPONENT_ROLES["rig"],
            lineage_id=lineage_id,
            rig_name=rig.name,
        )
        rig["cmk_origin_source"] = origin_source
        rig["cmk_insertion_source"] = insertion_source
        rig["cmk_endpoint_route"] = endpoint_route
        rig["cmk_endpoint_strategy"] = endpoint_strategy
        origin = _new_muscle_handle(
            names["origin"],
            role=core.MUSCLE_COMPONENT_ROLES["origin"],
            location=origin_world,
            rotation=origin_rotation,
            dimensions=attachment_dimensions,
            parent=rig,
            collection=collection,
            lineage_id=lineage_id,
            display_type="CIRCLE",
        )
        created_objects.append(origin)
        belly = _new_muscle_handle(
            names["belly"],
            role=core.MUSCLE_COMPONENT_ROLES["belly"],
            location=(origin_world + insertion_world) * 0.5,
            rotation=direction_rotation,
            dimensions=belly_dimensions,
            parent=rig,
            collection=collection,
            lineage_id=lineage_id,
            display_type="SPHERE",
        )
        created_objects.append(belly)
        insertion = _new_muscle_handle(
            names["insertion"],
            role=core.MUSCLE_COMPONENT_ROLES["insertion"],
            location=insertion_world,
            rotation=insertion_rotation,
            dimensions=attachment_dimensions,
            parent=rig,
            collection=collection,
            lineage_id=lineage_id,
            display_type="CIRCLE",
        )
        created_objects.append(insertion)

        mesh = bpy.data.meshes.new(f"{names['surface']} Mesh")
        created_data.append(mesh)
        surface = bpy.data.objects.new(names["surface"], mesh)
        created_objects.append(surface)
        collection.objects.link(surface)
        surface.parent = rig
        _stamp_muscle_component(
            surface,
            role=core.MUSCLE_COMPONENT_ROLES["surface"],
            lineage_id=lineage_id,
            rig_name=rig.name,
        )

        curve = bpy.data.curves.new(f"{names['path']} Curve", "CURVE")
        created_data.append(curve)
        curve.dimensions = "3D"
        curve.resolution_u = 2
        curve.bevel_depth = max(length * 0.004, 0.002)
        curve.bevel_resolution = 2
        curve.materials.append(bpy.data.materials["CMK | Segment Axis"])
        path = bpy.data.objects.new(names["path"], curve)
        created_objects.append(path)
        collection.objects.link(path)
        path.parent = rig
        path.show_in_front = True
        path.hide_render = True
        path.hide_select = True
        _stamp_muscle_component(
            path,
            role=core.MUSCLE_COMPONENT_ROLES["path"],
            lineage_id=lineage_id,
            rig_name=rig.name,
        )

        for key, component in (
            ("surface", surface),
            ("path", path),
            ("origin", origin),
            ("belly", belly),
            ("insertion", insertion),
        ):
            rig[f"cmk_{key}_name"] = component.name

        context.view_layer.update()
        try:
            _update_muscle_rig(rig)
        except ValueError as error:
            if str(error) != "origin and insertion must be distinct":
                raise
            failed_spec = _muscle_build_spec(rig)
            raise ValueError(
                core.muscle_endpoint_failure_message(
                    route=endpoint_route,
                    strategy=endpoint_strategy,
                    stage="initial_surface_build",
                    origin=failed_spec.origin,
                    insertion=failed_spec.insertion,
                )
            ) from error
    except Exception:
        for obj in reversed(created_objects):
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        for data in reversed(created_data):
            if getattr(data, "users", 1) == 0:
                if isinstance(data, bpy.types.Mesh):
                    bpy.data.meshes.remove(data)
                elif isinstance(data, bpy.types.Curve):
                    bpy.data.curves.remove(data)
        raise

    bpy.ops.object.select_all(action="DESELECT")
    belly.select_set(True)
    context.view_layer.objects.active = belly
    return rig, belly


class CMK_OT_create_muscle(bpy.types.Operator):
    bl_idname = "cmk.create_muscle"
    bl_label = "Create Muscle from 2 Selected"
    bl_description = "Create an editable procedural muscle between two selected object origins; the active object is insertion"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and len(context.selected_objects) == 2

    def execute(self, context):
        insertion_source = context.active_object
        if insertion_source is None or insertion_source not in context.selected_objects:
            self.report({"ERROR"}, "one selected object must be active as insertion")
            return {"CANCELLED"}
        origin_source = next(
            obj for obj in context.selected_objects if obj is not insertion_source
        )
        try:
            def geometry_center(obj):
                corners = tuple(
                    obj.matrix_world @ Vector(corner)
                    for corner in obj.bound_box
                )
                return sum(corners, Vector()) / len(corners)

            endpoints = core.resolve_selected_muscle_endpoints(
                origin_object=tuple(origin_source.matrix_world.translation),
                insertion_object=tuple(insertion_source.matrix_world.translation),
                origin_geometry=tuple(geometry_center(origin_source)),
                insertion_geometry=tuple(geometry_center(insertion_source)),
            )
            rig, _ = _create_muscle_rig(
                context,
                origin_world=Vector(endpoints.origin),
                insertion_world=Vector(endpoints.insertion),
                origin_rotation=origin_source.matrix_world.to_quaternion(),
                insertion_rotation=insertion_source.matrix_world.to_quaternion(),
                origin_source=origin_source.name,
                insertion_source=insertion_source.name,
                endpoint_route="selected_objects",
                endpoint_strategy=endpoints.strategy,
            )
        except ValueError as error:
            self.report({"ERROR"}, f"Create Muscle failed [route=selected_objects]: {error}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Created {rig.name}; belly handle selected")
        return {"FINISHED"}


class CMK_OT_draw_muscle(bpy.types.Operator):
    bl_idname = "cmk.draw_muscle"
    bl_label = "Draw Muscle"
    bl_description = "Click an origin surface and an insertion surface to create an editable procedural muscle"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    _origin_location = None
    _origin_normal = None
    _origin_source = ""
    _view_region = None
    _region_3d = None
    _viewport_armed = False

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and context.area and context.area.type == "VIEW_3D"

    def _finish(self, context) -> None:
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)

    def invoke(self, context, event):
        self._view_region = next(
            (region for region in context.area.regions if region.type == "WINDOW"),
            None,
        )
        self._region_3d = getattr(context.space_data, "region_3d", None)
        if self._view_region is None or self._region_3d is None:
            self.report({"ERROR"}, "Draw Muscle requires an active 3D View window region")
            return {"CANCELLED"}
        self._origin_location = None
        self._origin_normal = None
        self._origin_source = ""
        self._viewport_armed = False
        context.window.cursor_modal_set("CROSSHAIR")
        context.workspace.status_text_set(
            "Move into the viewport to arm Draw Muscle; Esc cancels",
        )
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish(context)
            return {"CANCELLED"}

        if not self._viewport_armed:
            if event.type == "MOUSEMOVE":
                coordinate = (
                    event.mouse_x - self._view_region.x,
                    event.mouse_y - self._view_region.y,
                )
                if (
                    0 <= coordinate[0] < self._view_region.width
                    and 0 <= coordinate[1] < self._view_region.height
                ):
                    self._viewport_armed = True
                    context.workspace.status_text_set(
                        "Muscle origin: click a mesh surface; Esc cancels",
                    )
            return {"RUNNING_MODAL"}

        if event.type != "LEFTMOUSE" or event.value != "PRESS":
            return {"RUNNING_MODAL"}

        coordinate = (
            event.mouse_x - self._view_region.x,
            event.mouse_y - self._view_region.y,
        )
        if not (
            0 <= coordinate[0] < self._view_region.width
            and 0 <= coordinate[1] < self._view_region.height
        ):
            return {"RUNNING_MODAL"}
        ray_origin = view3d_utils.region_2d_to_origin_3d(
            self._view_region,
            self._region_3d,
            coordinate,
        )
        ray_direction = view3d_utils.region_2d_to_vector_3d(
            self._view_region,
            self._region_3d,
            coordinate,
        )
        hit, location, normal, _, hit_object, _ = context.scene.ray_cast(
            context.view_layer.depsgraph,
            ray_origin,
            ray_direction,
        )
        if not hit:
            self.report({"WARNING"}, "no mesh surface under the cursor")
            return {"RUNNING_MODAL"}

        if self._origin_location is None:
            self._origin_location = location.copy()
            self._origin_normal = normal.copy()
            self._origin_source = hit_object.name
            context.workspace.status_text_set(
                "Muscle insertion: click a second mesh surface; Esc cancels",
            )
            return {"RUNNING_MODAL"}

        if (location - self._origin_location).length <= 1.0e-6:
            self.report(
                {"WARNING"},
                "insertion coincides with origin; click a different surface point",
            )
            context.workspace.status_text_set(
                "Muscle insertion: click a distinct surface point; Esc cancels",
            )
            return {"RUNNING_MODAL"}

        try:
            rig, _ = _create_muscle_rig(
                context,
                origin_world=self._origin_location,
                insertion_world=location.copy(),
                origin_rotation=self._origin_normal.to_track_quat("Z", "Y"),
                insertion_rotation=normal.to_track_quat("Z", "Y"),
                origin_source=self._origin_source,
                insertion_source=hit_object.name,
                endpoint_route="draw_muscle",
                endpoint_strategy="surface_hits",
            )
        except ValueError as error:
            self.report({"ERROR"}, f"Draw Muscle failed [route=draw_muscle]: {error}")
            self._finish(context)
            return {"CANCELLED"}

        self._finish(context)
        self.report({"INFO"}, f"Created {rig.name}; belly handle selected")
        return {"FINISHED"}


def _paint_coordinate(event, region) -> tuple[float, float]:
    return (event.mouse_x - region.x, event.mouse_y - region.y)


def _paint_coordinate_inside(coordinate, region) -> bool:
    return 0 <= coordinate[0] < region.width and 0 <= coordinate[1] < region.height


def _append_spaced_sample(
    samples: list[dict[str, object]],
    sample: dict[str, object],
) -> bool:
    if samples:
        previous = Vector(samples[-1]["world_position"])
        current = Vector(sample["world_position"])
        spacing = min(float(samples[-1]["radius"]), float(sample["radius"])) * 0.35
        if (current - previous).length < spacing:
            return False
    samples.append(sample)
    return True


def _create_painted_muscle(
    context,
    origin_samples: list[dict[str, object]],
    insertion_samples: list[dict[str, object]],
) -> bpy.types.Object:
    def average_vector(samples, key):
        return sum((Vector(sample[key]) for sample in samples), Vector()) / len(samples)

    origin_world = average_vector(origin_samples, "world_position")
    insertion_world = average_vector(insertion_samples, "world_position")
    origin_normal = average_vector(origin_samples, "world_normal").normalized()
    insertion_normal = average_vector(insertion_samples, "world_normal").normalized()
    rig: bpy.types.Object | None = None
    try:
        rig, _ = _create_muscle_rig(
            context,
            origin_world=origin_world,
            insertion_world=insertion_world,
            origin_rotation=origin_normal.to_track_quat("Z", "Y"),
            insertion_rotation=insertion_normal.to_track_quat("Z", "Y"),
            origin_source=str(origin_samples[0]["source_object"]),
            insertion_source=str(insertion_samples[0]["source_object"]),
            endpoint_route="painted_attachments",
            endpoint_strategy="painted_fields",
        )
        rig["cmk_muscle_kind"] = "PATCH"
        _write_attachment_samples(rig, "origin", origin_samples)
        _write_attachment_samples(rig, "insertion", insertion_samples)
        _update_patch_muscle_rig(rig)
    except Exception:
        if rig is not None:
            _remove_generated_muscle_rig(rig)
        raise
    surface = _rig_component(rig, "surface")
    bpy.ops.object.select_all(action="DESELECT")
    surface.select_set(True)
    context.view_layer.objects.active = surface
    _set_muscle_display(context, "SELECTED")
    return rig


def _remove_generated_muscle_rig(rig: bpy.types.Object) -> None:
    generated = [*rig.children_recursive, rig]
    for obj in reversed(generated):
        if obj.name not in bpy.data.objects:
            continue
        data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if data is None or data.users:
            continue
        if isinstance(data, bpy.types.Mesh):
            bpy.data.meshes.remove(data)
        elif isinstance(data, bpy.types.Curve):
            bpy.data.curves.remove(data)


class CMK_OT_paint_new_muscle(bpy.types.Operator):
    bl_idname = "cmk.paint_new_muscle"
    bl_label = "Paint New Muscle"
    bl_description = "Paint an anatomical Origin field, press Enter, then paint Insertion and press Enter to create a coherent patch muscle"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    _view_region = None
    _region_3d = None
    _viewport_armed = False
    _painting = False
    _field = "origin"
    _origin_samples = None
    _insertion_samples = None

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and context.area and context.area.type == "VIEW_3D"

    def _finish(self, context) -> None:
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)

    def invoke(self, context, event):
        self._view_region = next(
            (region for region in context.area.regions if region.type == "WINDOW"),
            None,
        )
        self._region_3d = getattr(context.space_data, "region_3d", None)
        if self._view_region is None or self._region_3d is None:
            self.report({"ERROR"}, "Paint New Muscle requires an active 3D View")
            return {"CANCELLED"}
        self._viewport_armed = False
        self._painting = False
        self._field = "origin"
        self._origin_samples = []
        self._insertion_samples = []
        context.window.cursor_modal_set("CROSSHAIR")
        context.workspace.status_text_set("Move into the viewport to arm Origin paint; Esc cancels")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish(context)
            return {"CANCELLED"}
        coordinate = _paint_coordinate(event, self._view_region)
        if not self._viewport_armed:
            if event.type == "MOUSEMOVE" and _paint_coordinate_inside(coordinate, self._view_region):
                self._viewport_armed = True
                context.workspace.status_text_set(
                    "Paint Origin with left-drag; Enter advances to Insertion; Esc cancels"
                )
            return {"RUNNING_MODAL"}

        if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS":
            samples = self._origin_samples if self._field == "origin" else self._insertion_samples
            if not samples:
                self.report({"WARNING"}, f"paint at least one {self._field.title()} sample")
                return {"RUNNING_MODAL"}
            if self._field == "origin":
                self._field = "insertion"
                self._painting = False
                context.workspace.status_text_set(
                    "Paint Insertion with left-drag; Enter creates the muscle; Esc cancels"
                )
                return {"RUNNING_MODAL"}
            try:
                rig = _create_painted_muscle(
                    context,
                    self._origin_samples,
                    self._insertion_samples,
                )
            except (KeyError, RuntimeError, TypeError, ValueError) as error:
                self.report({"ERROR"}, f"Painted muscle failed: {error}")
                self._finish(context)
                return {"CANCELLED"}
            self._finish(context)
            self.report({"INFO"}, f"Created {rig.name} from painted Origin and Insertion")
            return {"FINISHED"}

        if event.type == "LEFTMOUSE":
            self._painting = event.value == "PRESS"
            if event.value not in {"PRESS", "RELEASE"}:
                return {"RUNNING_MODAL"}
        should_sample = (
            event.type == "LEFTMOUSE" and event.value == "PRESS"
        ) or (event.type == "MOUSEMOVE" and self._painting)
        if not should_sample or not _paint_coordinate_inside(coordinate, self._view_region):
            return {"RUNNING_MODAL"}

        ray_origin = view3d_utils.region_2d_to_origin_3d(
            self._view_region, self._region_3d, coordinate
        )
        ray_direction = view3d_utils.region_2d_to_vector_3d(
            self._view_region, self._region_3d, coordinate
        )
        hit, location, normal, face_index, hit_object, _ = context.scene.ray_cast(
            context.view_layer.depsgraph, ray_origin, ray_direction
        )
        if not hit or hit_object.type != "MESH":
            return {"RUNNING_MODAL"}
        if hit_object.get("cmk_role") in {
            core.MUSCLE_COMPONENT_ROLES["surface"],
            core.MUSCLE_COMPONENT_ROLES["frozen"],
            *_PATCH_MARKER_ROLES,
        }:
            self.report({"WARNING"}, "paint on authored skeletal geometry, not generated muscle output")
            return {"RUNNING_MODAL"}
        sample = _attachment_sample_from_hit(
            hit_object,
            location,
            normal,
            face_index,
            float(context.window_manager.cmk_attachment_brush_radius),
        )
        samples = self._origin_samples if self._field == "origin" else self._insertion_samples
        _append_spaced_sample(samples, sample)
        context.workspace.status_text_set(
            f"{self._field.title()}: {len(samples)} samples; left-drag paints, Enter continues"
        )
        return {"RUNNING_MODAL"}


def _set_patch_authoring_visibility(rig: bpy.types.Object, hidden: bool) -> None:
    for child in rig.children:
        if child.get("cmk_role") in {
            core.MUSCLE_COMPONENT_ROLES["surface"],
            *_PATCH_MARKER_ROLES,
        }:
            child.hide_set(hidden)


class CMK_OT_repaint_muscle_attachment(bpy.types.Operator):
    bl_idname = "cmk.repaint_muscle_attachment"
    bl_label = "Repaint Attachment"
    bl_description = "Replace the active patch muscle's painted Origin or Insertion field"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    attachment: EnumProperty(
        name="Attachment",
        items=(
            ("ORIGIN", "Origin", "Repaint the anatomical Origin field"),
            ("INSERTION", "Insertion", "Repaint the anatomical Insertion field"),
        ),
    )
    _rig_name = ""
    _view_region = None
    _region_3d = None
    _viewport_armed = False
    _painting = False
    _samples = None

    @classmethod
    def poll(cls, context):
        rig = _muscle_rig_for_object(context.active_object)
        return bool(context.mode == "OBJECT" and rig and rig.get("cmk_muscle_kind") == "PATCH")

    def _finish(self, context) -> None:
        rig = bpy.data.objects.get(self._rig_name)
        if rig is not None:
            _set_patch_authoring_visibility(rig, False)
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)

    def invoke(self, context, event):
        rig = _muscle_rig_for_object(context.active_object)
        self._rig_name = rig.name
        self._view_region = next(
            (region for region in context.area.regions if region.type == "WINDOW"),
            None,
        )
        self._region_3d = getattr(context.space_data, "region_3d", None)
        if self._view_region is None or self._region_3d is None:
            self.report({"ERROR"}, "Repaint Attachment requires an active 3D View")
            return {"CANCELLED"}
        self._viewport_armed = False
        self._painting = False
        self._samples = []
        _set_patch_authoring_visibility(rig, True)
        context.window.cursor_modal_set("CROSSHAIR")
        context.workspace.status_text_set(
            f"Move into the viewport to arm {self.attachment.title()} repaint; Esc preserves the old field"
        )
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        rig = bpy.data.objects.get(self._rig_name)
        if rig is None or event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish(context)
            return {"CANCELLED"}
        coordinate = _paint_coordinate(event, self._view_region)
        if not self._viewport_armed:
            if event.type == "MOUSEMOVE" and _paint_coordinate_inside(coordinate, self._view_region):
                self._viewport_armed = True
            return {"RUNNING_MODAL"}
        if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS":
            if not self._samples:
                self.report({"WARNING"}, "paint at least one sample before finishing")
                return {"RUNNING_MODAL"}
            field = self.attachment.lower()
            evidence_snapshot = _attachment_evidence_snapshot(rig)
            _write_attachment_samples(rig, field, self._samples)
            try:
                _update_patch_muscle_rig(rig)
            except (KeyError, RuntimeError, TypeError, ValueError) as error:
                _restore_attachment_evidence(rig, evidence_snapshot)
                try:
                    _update_patch_muscle_rig(rig)
                except (KeyError, RuntimeError, TypeError, ValueError) as rollback_error:
                    message = f"Repaint failed: {error}; rollback failed: {rollback_error}"
                    rig["cmk_update_error"] = message
                    self.report({"ERROR"}, message)
                else:
                    self.report({"ERROR"}, f"Repaint failed: {error}; previous field restored")
                self._finish(context)
                return {"CANCELLED"}
            self._finish(context)
            self.report({"INFO"}, f"Repainted {rig.name} {field}")
            return {"FINISHED"}
        if event.type == "LEFTMOUSE":
            self._painting = event.value == "PRESS"
        should_sample = (
            event.type == "LEFTMOUSE" and event.value == "PRESS"
        ) or (event.type == "MOUSEMOVE" and self._painting)
        if not should_sample or not _paint_coordinate_inside(coordinate, self._view_region):
            return {"RUNNING_MODAL"}
        ray_origin = view3d_utils.region_2d_to_origin_3d(
            self._view_region, self._region_3d, coordinate
        )
        ray_direction = view3d_utils.region_2d_to_vector_3d(
            self._view_region, self._region_3d, coordinate
        )
        hit, location, normal, face_index, hit_object, _ = context.scene.ray_cast(
            context.view_layer.depsgraph, ray_origin, ray_direction
        )
        if hit and hit_object.type == "MESH" and hit_object.get("cmk_role") not in {
            core.MUSCLE_COMPONENT_ROLES["surface"],
            core.MUSCLE_COMPONENT_ROLES["frozen"],
            *_PATCH_MARKER_ROLES,
        }:
            sample = _attachment_sample_from_hit(
                hit_object,
                location,
                normal,
                face_index,
                float(context.window_manager.cmk_attachment_brush_radius),
            )
            _append_spaced_sample(self._samples, sample)
            context.workspace.status_text_set(
                f"{self.attachment.title()}: {len(self._samples)} samples; Enter replaces the field"
            )
        return {"RUNNING_MODAL"}


class CMK_OT_refresh_muscle(bpy.types.Operator):
    bl_idname = "cmk.refresh_muscle"
    bl_label = "Refresh Muscle"
    bl_description = "Rebuild the active procedural muscle from its authored handles and intervals"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _muscle_rig_for_object(context.active_object) is not None

    def execute(self, context):
        rig = _muscle_rig_for_object(context.active_object)
        try:
            _update_muscle_rig(rig)
        except (KeyError, RuntimeError, TypeError, ValueError) as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Refreshed {rig.name}")
        return {"FINISHED"}


class CMK_OT_set_muscle_display(bpy.types.Operator):
    bl_idname = "cmk.set_muscle_display"
    bl_label = "Set Muscle Display"
    bl_description = "Choose which procedural muscle controls are visible without changing geometry"
    bl_options = {"REGISTER", "UNDO"}

    display_mode: EnumProperty(
        name="Display",
        items=(
            ("FORM", "Form Only", "Hide every CMK muscle control and path"),
            ("SELECTED", "Selected", "Show controls only for the active muscle"),
            ("ALL", "All", "Show controls for every procedural muscle"),
        ),
    )

    def execute(self, context):
        try:
            visible, hidden, incomplete = _set_muscle_display(
                context,
                self.display_mode,
            )
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        incomplete_suffix = (
            f"; {len(incomplete)} incomplete rig"
            f"{'s' if len(incomplete) != 1 else ''} recorded"
            if incomplete
            else ""
        )
        self.report(
            {"INFO"},
            f"Muscle display {self.display_mode.lower()}: "
            f"{visible} controls visible, {hidden} hidden"
            f"{incomplete_suffix}",
        )
        return {"FINISHED"}


class CMK_OT_toggle_muscle_display(bpy.types.Operator):
    bl_idname = "cmk.toggle_muscle_display"
    bl_label = "Toggle Active Muscle Controls"
    bl_description = "Toggle between Form and Active muscle display"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and _muscle_rig_for_object(context.active_object) is not None

    def execute(self, context):
        current = str(context.scene.get("cmk_muscle_display_mode", "FORM"))
        target = "FORM" if current == "SELECTED" else "SELECTED"
        try:
            _set_muscle_display(context, target)
        except ValueError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Muscle display {target.lower()}")
        return {"FINISHED"}


class CMK_OT_select_muscle_handle(bpy.types.Operator):
    bl_idname = "cmk.select_muscle_handle"
    bl_label = "Select Muscle Handle"
    bl_description = "Select a named authored handle and isolate its muscle controls"
    bl_options = {"REGISTER"}

    handle_key: EnumProperty(
        name="Handle",
        items=(
            ("ORIGIN", "Origin", "Select the origin attachment handle"),
            ("BELLY", "Belly", "Select the belly routing and profile handle"),
            ("INSERTION", "Insertion", "Select the insertion attachment handle"),
        ),
    )

    @classmethod
    def poll(cls, context):
        return _muscle_rig_for_object(context.active_object) is not None

    def execute(self, context):
        rig = _muscle_rig_for_object(context.active_object)
        try:
            handle = _rig_component(rig, self.handle_key.lower())
            _set_muscle_display(context, "SELECTED")
        except (KeyError, RuntimeError, TypeError, ValueError) as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        handle.hide_select = False
        handle.hide_set(False)
        handle.select_set(True)
        context.view_layer.objects.active = handle
        self.report({"INFO"}, f"Selected {self.handle_key.title()} handle")
        return {"FINISHED"}


class CMK_OT_audit_muscles(bpy.types.Operator):
    bl_idname = "cmk.audit_muscles"
    bl_label = "Audit Muscles"
    bl_description = "Classify every muscle as refreshable, reconstructible, or requiring remake"
    bl_options = {"REGISTER"}

    def execute(self, context):
        result = _audit_all_muscles(context.scene)
        summary = result["summary"]
        self.report(
            {"INFO"},
            f"Muscle audit: {summary['refreshable']} refreshable, "
            f"{summary['reconstructible']} reconstructible, "
            f"{summary['remake_required']} remake required, "
            f"{summary['orphan_components']} orphan components",
        )
        return {"FINISHED"}


class CMK_OT_repair_muscles(bpy.types.Operator):
    bl_idname = "cmk.repair_muscles"
    bl_label = "Repair All Muscles"
    bl_description = "Refresh complete rigs and reconstruct recoverable missing components without deleting authored evidence"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        global _MUSCLE_UPDATE_GUARD
        _initialize_scene(context.scene)
        result = _audit_all_muscles(context.scene)
        repaired = 0
        refreshed = 0
        remake_required = 0
        failed = 0
        _MUSCLE_UPDATE_GUARD = True
        try:
            for rig_name, audit in result["audits"].items():
                rig = bpy.data.objects.get(rig_name)
                if rig is None:
                    continue
                if audit["status"] == "remake_required":
                    remake_required += 1
                    continue
                try:
                    recovered = _recover_muscle_rig(context, rig, audit)
                    repaired += int(bool(recovered))
                    refreshed += int(not recovered)
                except (KeyError, RuntimeError, TypeError, ValueError) as error:
                    rig["cmk_recovery_status"] = "remake_required"
                    rig["cmk_recovery_error"] = str(error)
                    failed += 1
        finally:
            _MUSCLE_UPDATE_GUARD = False
        _audit_all_muscles(context.scene)
        self.report(
            {"INFO"},
            f"Muscle repair: {refreshed} refreshed, {repaired} reconstructed, "
            f"{remake_required + failed} require remake; no objects deleted",
        )
        return {"FINISHED"}


def _move_object_to_collection(
    obj: bpy.types.Object,
    collection: bpy.types.Collection,
) -> None:
    if obj.name not in collection.objects:
        collection.objects.link(obj)
    for existing in tuple(obj.users_collection):
        if existing is not collection:
            existing.objects.unlink(obj)
    obj.hide_set(True)


class CMK_OT_quarantine_muscles(bpy.types.Operator):
    bl_idname = "cmk.quarantine_muscles"
    bl_label = "Quarantine Remake Required"
    bl_description = "Move and hide underdetermined rigs and orphan components without deleting them"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        result = _audit_all_muscles(context.scene)
        quarantine, _ = _ensure_collection_path(
            context.scene,
            (core.ROOT_COLLECTION, "20 Muscle", _MUSCLE_RECOVERY_QUARANTINE),
        )
        quarantined_rigs = 0
        quarantined_names: set[str] = set()
        for rig_name, audit in result["audits"].items():
            if audit["status"] != "remake_required":
                continue
            rig = bpy.data.objects.get(rig_name)
            if rig is None:
                continue
            objects = {rig.name: rig}
            for values in audit["candidates"].values():
                objects.update((obj.name, obj) for obj in values)
            for obj in objects.values():
                _move_object_to_collection(obj, quarantine)
                quarantined_names.add(obj.name)
            rig["cmk_recovery_quarantined"] = True
            quarantined_rigs += 1

        for obj in result["orphan_components"]:
            _move_object_to_collection(obj, quarantine)
            quarantined_names.add(obj.name)
        context.scene["cmk_muscle_quarantined_objects"] = ", ".join(
            sorted(quarantined_names)
        )
        self.report(
            {"INFO"},
            f"Quarantined {quarantined_rigs} remake-required rigs and "
            f"{len(result['orphan_components'])} orphan components; nothing deleted",
        )
        return {"FINISHED"}


class CMK_OT_rename_muscles(bpy.types.Operator):
    bl_idname = "cmk.rename_muscles"
    bl_label = "Rename Selected Muscles"
    bl_description = "Apply one name to the active muscle or a numbered stem to every selected muscle"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(_selected_muscle_rigs(context))

    def execute(self, context):
        rigs = _selected_muscle_rigs(context)
        try:
            plans = _rename_muscle_rigs(
                rigs,
                context.window_manager.cmk_muscle_name_stem,
            )
        except (KeyError, RuntimeError, TypeError, ValueError) as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"Renamed {len(plans)} muscle{'s' if len(plans) != 1 else ''}",
        )
        return {"FINISHED"}


class CMK_OT_freeze_muscle(bpy.types.Operator):
    bl_idname = "cmk.freeze_muscle"
    bl_label = "Freeze Muscle to Mesh"
    bl_description = "Create an ordinary editable mesh branch while preserving the procedural muscle rig"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _muscle_rig_for_object(context.active_object) is not None

    def execute(self, context):
        rig = _muscle_rig_for_object(context.active_object)
        try:
            _update_muscle_rig(rig)
            source = _rig_component(rig, "surface")
            collection, _ = _ensure_collection_path(
                context.scene,
                (core.ROOT_COLLECTION, "20 Muscle"),
            )
            frozen_name = core.next_numbered_name(
                f"{rig.name} | Frozen",
                set(bpy.data.objects.keys()),
            )
            identity = core.ensure_source_identity(
                {},
                construction_hint=frozen_name,
                lineage_id=str(rig["cmk_lineage_id"]),
                id_factory=_new_id,
            )
            identity.update(
                {
                    "cmk_role": core.MUSCLE_COMPONENT_ROLES["frozen"],
                    "cmk_muscle_rig_name": rig.name,
                    "cmk_source_instance_id": str(source["cmk_instance_id"]),
                    "cmk_completeness": "wip_frozen_geometry",
                },
            )
            world_transform = source.matrix_world.copy()
        except (KeyError, RuntimeError, TypeError, ValueError) as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        frozen = None
        frozen_mesh = None
        try:
            frozen_mesh = source.data.copy()
            frozen = source.copy()
            frozen.data = frozen_mesh
            frozen.name = frozen_name
            collection.objects.link(frozen)
            frozen.parent = None
            frozen.matrix_world = world_transform
            for key in IDENTITY_KEYS:
                if key in frozen:
                    del frozen[key]
            _write_properties(frozen, identity)

            bpy.ops.object.select_all(action="DESELECT")
            frozen.select_set(True)
            context.view_layer.objects.active = frozen
        except Exception as error:
            if frozen is not None and frozen.name in bpy.data.objects:
                bpy.data.objects.remove(frozen, do_unlink=True)
            if frozen_mesh is not None and frozen_mesh.users == 0:
                bpy.data.meshes.remove(frozen_mesh)
            self.report({"ERROR"}, f"freeze failed without output: {error}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Created editable branch {frozen.name}")
        return {"FINISHED"}


@persistent
def _muscle_depsgraph_update(scene, depsgraph) -> None:
    global _MUSCLE_PENDING_UPDATES
    if _MUSCLE_UPDATE_GUARD:
        return

    for update in depsgraph.updates:
        updated = update.id
        if not isinstance(updated, bpy.types.Object):
            continue
        if updated.get("cmk_role") in _MUSCLE_DYNAMIC_ROLES:
            rig = _muscle_rig_for_object(updated)
            if rig is not None:
                _MUSCLE_PENDING_UPDATES.add(rig.name)
        for patch_rig in _muscle_rigs():
            if patch_rig.get("cmk_muscle_kind") != "PATCH":
                continue
            try:
                source_names = json.loads(
                    str(patch_rig.get("cmk_patch_source_names", "[]"))
                )
            except json.JSONDecodeError:
                source_names = []
            if updated.name in source_names:
                _MUSCLE_PENDING_UPDATES.add(patch_rig.name)
    if _MUSCLE_PENDING_UPDATES and not bpy.app.timers.is_registered(
        _flush_pending_muscle_updates
    ):
        bpy.app.timers.register(_flush_pending_muscle_updates, first_interval=0.0)


def _flush_pending_muscle_updates():
    global _MUSCLE_UPDATE_GUARD
    if _MUSCLE_UPDATE_GUARD:
        return 0.05

    pending = tuple(sorted(_MUSCLE_PENDING_UPDATES))
    _MUSCLE_PENDING_UPDATES.clear()
    if not pending:
        return None

    _MUSCLE_UPDATE_GUARD = True
    try:
        for rig_name in pending:
            rig = bpy.data.objects.get(rig_name)
            if (
                rig is None
                or rig.get("cmk_role") != core.MUSCLE_COMPONENT_ROLES["rig"]
            ):
                continue
            try:
                _update_muscle_rig(rig)
            except (KeyError, RuntimeError, TypeError, ValueError) as error:
                message = str(error)
                if rig.get("cmk_update_error") != message:
                    rig["cmk_update_error"] = message
    finally:
        _MUSCLE_UPDATE_GUARD = False
    return 0.0 if _MUSCLE_PENDING_UPDATES else None


class CMK_PT_constructional_modeling(bpy.types.Panel):
    bl_label = "Constructional Modeling"
    bl_idname = "CMK_PT_constructional_modeling"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Construction"

    def draw(self, context):
        layout = self.layout
        initialized = bpy.data.collections.get(core.ROOT_COLLECTION) is not None

        row = layout.row()
        row.operator(
            CMK_OT_initialize_scene.bl_idname,
            icon="OUTLINER_COLLECTION",
        )
        if initialized:
            row.label(text="", icon="CHECKMARK")

        layout.separator()
        layout.label(text="Assembly", icon="OBJECT_DATA")
        layout.operator(CMK_OT_stamp_parent.bl_idname, icon="DECORATE_KEYFRAME")
        layout.prop(context.window_manager, "cmk_sibling_label", text="Sibling")
        layout.operator(CMK_OT_fork_sibling.bl_idname, icon="DUPLICATE")

        layout.separator()
        layout.label(text="Procedural Muscle", icon="MOD_CURVE")
        muscle_actions = layout.column(align=True)
        muscle_actions.operator(CMK_OT_paint_new_muscle.bl_idname, icon="BRUSH_DATA")
        muscle_actions.operator(CMK_OT_draw_muscle.bl_idname, icon="ADD")
        muscle_actions.operator(CMK_OT_create_muscle.bl_idname)
        muscle_actions.prop(
            context.window_manager,
            "cmk_attachment_brush_radius",
            text="Paint Radius",
        )

        naming = layout.row(align=True)
        naming.prop(
            context.window_manager,
            "cmk_muscle_name_stem",
            text="Name",
        )
        naming.operator(
            CMK_OT_rename_muscles.bl_idname,
            text="",
            icon="GREASEPENCIL",
        )

        muscle_rig = _muscle_rig_for_object(context.active_object)
        if muscle_rig is not None:
            muscle_box = layout.box()
            muscle_box.label(text=muscle_rig.name, icon="OUTLINER_OB_CURVE")
            is_patch = muscle_rig.get("cmk_muscle_kind") == "PATCH"
            if is_patch:
                attachments = muscle_box.row(align=True)
                for field, label in (("ORIGIN", "Repaint Origin"), ("INSERTION", "Repaint Insertion")):
                    operator = attachments.operator(
                        CMK_OT_repaint_muscle_attachment.bl_idname,
                        text=label,
                    )
                    operator.attachment = field
                muscle_box.prop(muscle_rig, "cmk_patch_thickness", text="Thickness")
                muscle_box.prop(muscle_rig, "cmk_patch_belly_scale", text="Belly")
                muscle_box.prop(muscle_rig, "cmk_patch_bulge", text="Bulge")
                uncertain_count = int(muscle_rig.get("cmk_patch_uncertain_count", 0))
                if uncertain_count:
                    uncertainty = muscle_box.row()
                    uncertainty.alert = True
                    uncertainty.label(
                        text=f"{uncertain_count} attachment sample{'s' if uncertain_count != 1 else ''} need repaint",
                        icon="ERROR",
                    )
            else:
                handles = muscle_box.row(align=True)
                for key, label in (
                    ("ORIGIN", "Origin"),
                    ("BELLY", "Belly"),
                    ("INSERTION", "Insertion"),
                ):
                    operator = handles.operator(
                        CMK_OT_select_muscle_handle.bl_idname,
                        text=label,
                    )
                    operator.handle_key = key
            muscle_box.prop(
                muscle_rig,
                "cmk_origin_tendon_fraction",
                text="Origin Tendon",
                slider=True,
            )
            muscle_box.prop(
                muscle_rig,
                "cmk_insertion_tendon_fraction",
                text="Insertion Tendon",
                slider=True,
            )
            resolution = muscle_box.row(align=True)
            resolution.prop(
                muscle_rig,
                "cmk_longitudinal_sections",
                text="Length",
            )
            resolution.prop(
                muscle_rig,
                "cmk_profile_sides",
                text="Section",
            )
            operations = muscle_box.row(align=True)
            operations.operator(CMK_OT_refresh_muscle.bl_idname, text="Refresh")
            operations.operator(CMK_OT_freeze_muscle.bl_idname, text="Freeze")
            if "cmk_update_error" in muscle_rig:
                error = muscle_box.row()
                error.alert = True
                error.label(text=str(muscle_rig["cmk_update_error"]), icon="ERROR")

        display = layout.row(align=True)
        for mode, label, icon in (
            ("FORM", "Form", "HIDE_ON"),
            ("SELECTED", "Active", "RESTRICT_SELECT_OFF"),
            ("ALL", "All", "HIDE_OFF"),
        ):
            operator = display.operator(
                CMK_OT_set_muscle_display.bl_idname,
                text=label,
                icon=icon,
            )
            operator.display_mode = mode

        recovery = layout.column(align=True)
        recovery.operator(CMK_OT_audit_muscles.bl_idname, icon="VIEWZOOM")
        recovery.operator(CMK_OT_repair_muscles.bl_idname, icon="FILE_REFRESH")
        recovery.operator(CMK_OT_quarantine_muscles.bl_idname, icon="HIDE_ON")

        layout.separator()
        layout.label(text="Semantic Markers", icon="EMPTY_AXIS")
        marker_layout = layout.grid_flow(
            row_major=True,
            columns=2,
            even_columns=True,
            even_rows=True,
            align=True,
        )
        for key, spec in core.MARKER_SPECS.items():
            operator = marker_layout.operator(
                CMK_OT_add_marker.bl_idname,
                text=spec.label,
            )
            operator.marker_kind = key

        layout.separator()
        layout.label(text="Mesh Rescue", icon="TOOL_SETTINGS")
        rescue = layout.column(align=True)
        rescue.operator("mesh.bridge_edge_loops", text="Bridge Edge Loops")
        rescue.operator("mesh.fill_grid", text="Grid Fill")
        rescue.operator("mesh.remove_doubles", text="Merge by Distance")
        normals = rescue.operator(
            "mesh.normals_make_consistent",
            text="Recalculate Outside",
        )
        normals.inside = False

        active = context.active_object
        if active and "cmk_construction_id" in active:
            layout.separator()
            layout.label(text="Active Identity", icon="INFO")
            identity = layout.column(align=True)
            identity.label(text=f"Construction: {active['cmk_construction_id']}")
            identity.label(text=f"Variant: {active.get('cmk_variant', 'unknown')}")
            identity.label(text=f"Lineage: {str(active['cmk_lineage_id'])[:18]}...")


CLASSES = (
    CMK_OT_initialize_scene,
    CMK_OT_stamp_parent,
    CMK_OT_fork_sibling,
    CMK_OT_add_marker,
    CMK_OT_paint_new_muscle,
    CMK_OT_repaint_muscle_attachment,
    CMK_OT_create_muscle,
    CMK_OT_draw_muscle,
    CMK_OT_refresh_muscle,
    CMK_OT_set_muscle_display,
    CMK_OT_toggle_muscle_display,
    CMK_OT_select_muscle_handle,
    CMK_OT_audit_muscles,
    CMK_OT_repair_muscles,
    CMK_OT_quarantine_muscles,
    CMK_OT_rename_muscles,
    CMK_OT_freeze_muscle,
    CMK_PT_constructional_modeling,
)


def _register_keymaps() -> None:
    addon = bpy.context.window_manager.keyconfigs.addon
    if addon is None:
        return
    keymap = addon.keymaps.new(name="3D View", space_type="VIEW_3D")
    item = keymap.keymap_items.new(
        CMK_OT_toggle_muscle_display.bl_idname,
        type="A",
        value="PRESS",
        ctrl=True,
        shift=True,
    )
    _ADDON_KEYMAPS.append((keymap, item))


def _unregister_keymaps() -> None:
    for keymap, item in reversed(_ADDON_KEYMAPS):
        keymap.keymap_items.remove(item)
    _ADDON_KEYMAPS.clear()


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.cmk_sibling_label = StringProperty(
        name="Sibling Label",
        description="Short label for the controlled sibling variant",
        default="sibling",
    )
    bpy.types.WindowManager.cmk_muscle_name_stem = StringProperty(
        name="Muscle Name",
        description="Exact active-muscle name or numbered stem for selected muscles",
        default="Muscle",
    )
    bpy.types.WindowManager.cmk_attachment_brush_radius = FloatProperty(
        name="Attachment Paint Radius",
        description="World-space radius represented by each uncapped painted attachment sample",
        default=0.08,
        min=0.0001,
        soft_max=1.0,
        subtype="DISTANCE",
    )
    bpy.types.Object.cmk_origin_tendon_fraction = FloatProperty(
        name="Origin Tendon",
        description="Fraction of the path retained as the origin-side tendon interval",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_origin_tendon_fraction"],
        min=0.02,
        max=0.45,
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_insertion_tendon_fraction = FloatProperty(
        name="Insertion Tendon",
        description="Fraction of the path retained as the insertion-side tendon interval",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_insertion_tendon_fraction"],
        min=0.02,
        max=0.45,
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_longitudinal_sections = IntProperty(
        name="Length Sections",
        description="Half the longitudinal ring count used by the live surface",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_longitudinal_sections"],
        min=2,
        max=64,
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_profile_sides = IntProperty(
        name="Profile Sides",
        description="Cross-section resolution used by the live surface",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_profile_sides"],
        min=4,
        max=64,
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_patch_thickness = FloatProperty(
        name="Patch Thickness",
        description="Minimum depth of the generated painted muscle",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_patch_thickness"],
        min=0.0001,
        soft_max=1.0,
        subtype="DISTANCE",
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_patch_belly_scale = FloatProperty(
        name="Patch Belly Scale",
        description="Scale of the generated belly relative to the broader attachment field",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_patch_belly_scale"],
        min=0.05,
        soft_max=3.0,
        update=_muscle_setting_update,
    )
    bpy.types.Object.cmk_patch_bulge = FloatProperty(
        name="Patch Bulge",
        description="Signed offset of the generated belly along the fitted attachment normal",
        default=_MUSCLE_SETTING_DEFAULTS["cmk_patch_bulge"],
        soft_min=-1.0,
        soft_max=1.0,
        subtype="DISTANCE",
        update=_muscle_setting_update,
    )
    _register_keymaps()
    if not bpy.app.timers.is_registered(_deferred_migrate_muscle_settings):
        bpy.app.timers.register(
            _deferred_migrate_muscle_settings,
            first_interval=0.0,
        )
    if _muscle_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_muscle_depsgraph_update)


def unregister():
    _unregister_keymaps()
    if _muscle_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_muscle_depsgraph_update)
    if bpy.app.timers.is_registered(_deferred_migrate_muscle_settings):
        bpy.app.timers.unregister(_deferred_migrate_muscle_settings)
    if bpy.app.timers.is_registered(_flush_pending_muscle_updates):
        bpy.app.timers.unregister(_flush_pending_muscle_updates)
    _MUSCLE_PENDING_UPDATES.clear()
    del bpy.types.Object.cmk_patch_bulge
    del bpy.types.Object.cmk_patch_belly_scale
    del bpy.types.Object.cmk_patch_thickness
    del bpy.types.Object.cmk_profile_sides
    del bpy.types.Object.cmk_longitudinal_sections
    del bpy.types.Object.cmk_insertion_tendon_fraction
    del bpy.types.Object.cmk_origin_tendon_fraction
    del bpy.types.WindowManager.cmk_attachment_brush_radius
    del bpy.types.WindowManager.cmk_muscle_name_stem
    del bpy.types.WindowManager.cmk_sibling_label
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
