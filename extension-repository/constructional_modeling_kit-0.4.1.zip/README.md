# Constructional Modeling Kit

Relationship-first anatomy authoring helpers for Blender `5.1`.

After enabling the extension, open the 3D Viewport `N` sidebar and select
**Construction**. Initialize the scene, stamp a selected parent assembly, fork
a source-linked sibling, add semantic markers, and create procedural muscles
from two selected objects or two surface clicks.

For **Create Muscle from 2 Selected**, the active object is the insertion.
Distinct object origins are used when available; edited-in-place meshes with
coincident origins fall back to their world-space geometry centers. The
intended repaired behavior for **Draw Muscle** is to remain unarmed after its
sidebar activation, arm only after a mouse-move event enters the viewport, then
wait for an origin click followed by a distinct insertion click. Endpoint
failures include the creation route, endpoint strategy, failure stage,
coordinates, and distance. This intended repaired behavior has not yet
been exercised inside Blender 5.1; static tests and archive validation do not
admit that interactive-host claim. Source-bound Blender 5.1.2 evidence does
admit registration, selected-object creation, and component resolution after
display renames.

The intended rig retains named origin, belly, insertion, routed-path, and
provisional-surface objects. Source-bound Blender `5.1.2` evidence admits that
a handle transform enters the deferred rebuild queue and that direct exercise
of the queued timer callback updates the surface. Interactive timer cadence in
an open Blender session remains operator-live evidence rather than an admitted
background-host predicate. Explicit Refresh remains available; freeze, save,
and undo remain unexercised by the recovery witness.

Version `0.3.1` adds named Origin, Belly, and Insertion selection commands.
Active mode exposes the names of those three authored handles while the path
and plain-axis rig root remain visible but non-selectable. Display switching
continues across incomplete legacy rigs and records missing-surface identities
instead of throwing after partially changing visibility. A source-bound Blender
5.1.2 host witness admits all three exact-role selectors, exclusion of the path
and rig root from selection, and uninterrupted Form, Active, and All switching
with an intentionally incomplete rig present.

Version `0.3.2` adds scene-wide muscle audit, repair, and non-destructive
quarantine. Complete rigs refresh in bulk. Missing handles are reconstructed
only from recognized generated-surface profile rings; missing generated paths
or surfaces are reconstructed from complete authored handles. Conflicting or
underdetermined rigs are marked remake-required and can be moved and hidden in
the Recovery Quarantine collection without deletion. Handle-transform rebuilds
are deferred through Blender's timer queue so mesh replacement occurs after
dependency-graph evaluation; explicit Refresh remains available.

Version `0.3.3` fixes extension enablement under Blender's protected
registration state. Registration defines classes, properties, and handlers
without traversing scene objects; legacy muscle settings migrate on the first
unrestricted timer turn. A Blender `5.1.2` restricted-context witness admits
registration, deferred migration of a pre-existing setting, and unregistration.

Version `0.4.1` reloads the package-relative geometry core during extension
import so an in-process reinstall cannot pair the new initializer with a stale
cached helper module. Version `0.4.0` adds **Paint New Muscle**. Left-drag an anatomical Origin field,
press `Enter`, left-drag an Insertion field, then press `Enter` to create a
source-bound patch loft. Broad painted attachments can remain broad fans while
narrow fields taper into tendon. **Thickness**, **Belly**, and **Bulge** refine
the generated form without requiring its hidden generated handles.

Skeletal edits follow exact triangle and barycentric bindings only while mesh
identity and ordered connectivity still match. Replacement or reconnected
topology uses guarded nearest-surface projection: nearby coherent transfer stays
quiet, while material displacement or normal disagreement marks only affected
samples **Uncertain**. Yellow uncertain marks persist until the operator uses
**Repaint Origin** or **Repaint Insertion**; `Esc` preserves the old field.
Every failed patch refresh restores its prior evidence and generated data;
failed creation removes its incomplete rig. The painted-field path is additive:
existing Origin/Belly/Insertion axial muscles retain their controls and behavior.

The source-bound recovery witness also admits generated-component drift repair,
transactional rollback without fabricated handles, world-transform-preserving
repair of stale handle parents, and quarantine without deletion.

Source-bound Blender 5.1.2 evidence admits each sidebar property rebuild for
tendon fractions and resolution, independent of the general depsgraph handler.
The **Form**, **Active**, and **All** display modes change only CMK control
visibility while preserving every generated surface. `Ctrl+Shift+A` toggles
between **Active** and **Form** in the 3D Viewport.

New muscles use informative source names for source-pair provisional naming
and fall back to numbered `Muscle` labels for generic Blender object names.
Select one or more muscle surfaces or controls, enter a **Name**, and press the
tag button: one muscle receives the exact name and multiple muscles receive a
numbered batch naming sequence. Blender-host evidence proves the rename updates
all generated components while preserving persistent construction identities.

The extension never changes Blender preferences or the startup file. It mutates
only CMK-authored generated geometry after an explicit authoring command,
setting change, or handle transform.

A source-bound Blender `5.1.2` witness admits the patch form, same-topology
following, guarded topology replacement, meaningful uncertainty, hotkey
registration, failed-repaint rollback, and failed-creation cleanup. Live mouse
drag and keypress behavior remain operator-visible smoke predicates.
